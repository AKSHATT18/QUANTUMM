import { sql } from "drizzle-orm";
import { pgTable, text, varchar, real, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  amount: real("amount").notNull(),
  fromAccount: text("from_account").notNull(),
  toAccount: text("to_account").notNull(),
  institutionId: text("institution_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  features: jsonb("features").notNull(), // Encoded transaction features
  riskScore: real("risk_score"),
  isApproved: boolean("is_approved").default(true),
  isFraud: boolean("is_fraud").default(false),
});

export const quantumModels = pgTable("quantum_models", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  architecture: jsonb("architecture").notNull(), // Quantum circuit configuration
  parameters: jsonb("parameters").notNull(), // Model weights/parameters
  trainingEpochs: integer("training_epochs").default(0),
  reconstructionError: real("reconstruction_error"),
  accuracy: real("accuracy"),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const federatedNodes = pgTable("federated_nodes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  institutionType: text("institution_type").notNull(),
  isOnline: boolean("is_online").default(false),
  modelSyncProgress: real("model_sync_progress").default(0),
  latency: real("latency"), // in milliseconds
  privacyLevel: real("privacy_level").default(0.997),
  lastSeen: timestamp("last_seen").defaultNow(),
});

export const fraudAlerts = pgTable("fraud_alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  transactionId: varchar("transaction_id").notNull().references(() => transactions.id),
  alertType: text("alert_type").notNull(), // "high_risk", "suspicious_velocity", etc.
  riskScore: real("risk_score").notNull(),
  quantumConfidence: real("quantum_confidence").notNull(),
  description: text("description").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const modelMetrics = pgTable("model_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  modelId: varchar("model_id").notNull().references(() => quantumModels.id),
  accuracy: real("accuracy").notNull(),
  precision: real("precision").notNull(),
  recall: real("recall").notNull(),
  f1Score: real("f1_score").notNull(),
  falsePositiveRate: real("false_positive_rate").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  timestamp: true,
  riskScore: true,
});

export const insertQuantumModelSchema = createInsertSchema(quantumModels).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFederatedNodeSchema = createInsertSchema(federatedNodes).omit({
  id: true,
  lastSeen: true,
});

export const insertFraudAlertSchema = createInsertSchema(fraudAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertModelMetricsSchema = createInsertSchema(modelMetrics).omit({
  id: true,
  timestamp: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertQuantumModel = z.infer<typeof insertQuantumModelSchema>;
export type QuantumModel = typeof quantumModels.$inferSelect;
export type InsertFederatedNode = z.infer<typeof insertFederatedNodeSchema>;
export type FederatedNode = typeof federatedNodes.$inferSelect;
export type InsertFraudAlert = z.infer<typeof insertFraudAlertSchema>;
export type FraudAlert = typeof fraudAlerts.$inferSelect;
export type InsertModelMetrics = z.infer<typeof insertModelMetricsSchema>;
export type ModelMetrics = typeof modelMetrics.$inferSelect;

// WebSocket message types
export const WebSocketMessageSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("transaction_update"),
    data: z.object({
      transaction: z.any(),
      riskScore: z.number(),
      status: z.string(),
    }),
  }),
  z.object({
    type: z.literal("fraud_alert"),
    data: z.object({
      alert: z.any(),
      severity: z.string(),
    }),
  }),
  z.object({
    type: z.literal("model_update"),
    data: z.object({
      modelId: z.string(),
      metrics: z.any(),
      convergence: z.number(),
    }),
  }),
  z.object({
    type: z.literal("federated_sync"),
    data: z.object({
      nodeId: z.string(),
      syncProgress: z.number(),
      latency: z.number(),
    }),
  }),
  z.object({
    type: z.literal("training_progress"),
    data: z.object({
      epoch: z.number(),
      totalEpochs: z.number(),
      progress: z.number(),
      reconstructionError: z.number(),
      accuracy: z.number(),
      isComplete: z.boolean(),
    }),
  }),
  z.object({
    type: z.literal("training_complete"),
    data: z.object({
      modelId: z.string(),
      finalAccuracy: z.number(),
      finalError: z.number(),
      totalEpochs: z.number(),
      trainingTime: z.number(),
    }),
  }),
]);

export type WebSocketMessage = z.infer<typeof WebSocketMessageSchema>;
