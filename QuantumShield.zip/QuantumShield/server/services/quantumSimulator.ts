// Quantum Machine Learning Simulator using classical computation
export interface QuantumState {
  amplitudes: Complex[];
  qubits: number;
}

export interface Complex {
  real: number;
  imaginary: number;
}

export interface QuantumCircuit {
  gates: QuantumGate[];
  qubits: number;
}

export interface QuantumGate {
  type: 'H' | 'RY' | 'RZ' | 'CNOT' | 'MEASURE';
  target: number;
  control?: number;
  parameter?: number;
}

export class QuantumSimulator {
  private createZeroState(qubits: number): QuantumState {
    const size = Math.pow(2, qubits);
    const amplitudes: Complex[] = new Array(size).fill(null).map((_, i) => ({
      real: i === 0 ? 1 : 0,
      imaginary: 0
    }));
    return { amplitudes, qubits };
  }

  private multiplyComplex(a: Complex, b: Complex): Complex {
    return {
      real: a.real * b.real - a.imaginary * b.imaginary,
      imaginary: a.real * b.imaginary + a.imaginary * b.real
    };
  }

  private addComplex(a: Complex, b: Complex): Complex {
    return {
      real: a.real + b.real,
      imaginary: a.imaginary + b.imaginary
    };
  }

  private applyHadamard(state: QuantumState, target: number): QuantumState {
    const newState = { ...state, amplitudes: [...state.amplitudes] };
    const size = Math.pow(2, state.qubits);
    const targetMask = 1 << target;
    
    for (let i = 0; i < size; i++) {
      if ((i & targetMask) === 0) {
        const j = i | targetMask;
        const amp0 = state.amplitudes[i];
        const amp1 = state.amplitudes[j];
        
        newState.amplitudes[i] = {
          real: (amp0.real + amp1.real) / Math.sqrt(2),
          imaginary: (amp0.imaginary + amp1.imaginary) / Math.sqrt(2)
        };
        newState.amplitudes[j] = {
          real: (amp0.real - amp1.real) / Math.sqrt(2),
          imaginary: (amp0.imaginary - amp1.imaginary) / Math.sqrt(2)
        };
      }
    }
    
    return newState;
  }

  private applyRotationY(state: QuantumState, target: number, angle: number): QuantumState {
    const newState = { ...state, amplitudes: [...state.amplitudes] };
    const size = Math.pow(2, state.qubits);
    const targetMask = 1 << target;
    const cos = Math.cos(angle / 2);
    const sin = Math.sin(angle / 2);
    
    for (let i = 0; i < size; i++) {
      if ((i & targetMask) === 0) {
        const j = i | targetMask;
        const amp0 = state.amplitudes[i];
        const amp1 = state.amplitudes[j];
        
        newState.amplitudes[i] = {
          real: cos * amp0.real - sin * amp1.real,
          imaginary: cos * amp0.imaginary - sin * amp1.imaginary
        };
        newState.amplitudes[j] = {
          real: sin * amp0.real + cos * amp1.real,
          imaginary: sin * amp0.imaginary + cos * amp1.imaginary
        };
      }
    }
    
    return newState;
  }

  public executeCircuit(circuit: QuantumCircuit, inputData?: number[]): QuantumState {
    let state = this.createZeroState(circuit.qubits);
    
    // Encode input data if provided
    if (inputData) {
      for (let i = 0; i < Math.min(inputData.length, circuit.qubits); i++) {
        const angle = inputData[i] * Math.PI; // Amplitude encoding
        state = this.applyRotationY(state, i, angle);
      }
    }
    
    // Apply gates
    for (const gate of circuit.gates) {
      switch (gate.type) {
        case 'H':
          state = this.applyHadamard(state, gate.target);
          break;
        case 'RY':
          if (gate.parameter !== undefined) {
            state = this.applyRotationY(state, gate.target, gate.parameter);
          }
          break;
        // Additional gates can be implemented here
      }
    }
    
    return state;
  }

  public measureState(state: QuantumState): number[] {
    const probabilities = state.amplitudes.map(amp => 
      amp.real * amp.real + amp.imaginary * amp.imaginary
    );
    
    // Convert to classical output
    const output: number[] = [];
    for (let i = 0; i < state.qubits; i++) {
      let prob0 = 0;
      const mask = 1 << i;
      
      for (let j = 0; j < probabilities.length; j++) {
        if ((j & mask) === 0) {
          prob0 += probabilities[j];
        }
      }
      
      output.push(prob0 > 0.5 ? 0 : 1);
    }
    
    return output;
  }

  public calculateReconstructionError(original: number[], reconstructed: number[]): number {
    if (original.length !== reconstructed.length) {
      throw new Error("Arrays must have the same length");
    }
    
    const mse = original.reduce((sum, val, i) => {
      const diff = val - reconstructed[i];
      return sum + diff * diff;
    }, 0) / original.length;
    
    return Math.sqrt(mse);
  }
}

export class QuantumAutoencoder {
  private simulator: QuantumSimulator;
  private encoderCircuit: QuantumCircuit;
  private decoderCircuit: QuantumCircuit;
  private parameters: number[];

  constructor(inputQubits: number, encodedQubits: number) {
    this.simulator = new QuantumSimulator();
    this.parameters = new Array(inputQubits * 4).fill(0).map(() => Math.random() * 2 * Math.PI);
    
    // Create encoder circuit
    this.encoderCircuit = {
      qubits: inputQubits,
      gates: [
        ...Array.from({ length: inputQubits }, (_, i) => ({
          type: 'H' as const,
          target: i
        })),
        ...Array.from({ length: inputQubits }, (_, i) => ({
          type: 'RY' as const,
          target: i,
          parameter: this.parameters[i]
        })),
      ]
    };
    
    // Create decoder circuit (reverse of encoder)
    this.decoderCircuit = {
      qubits: inputQubits,
      gates: [
        ...Array.from({ length: inputQubits }, (_, i) => ({
          type: 'RY' as const,
          target: i,
          parameter: -this.parameters[i + inputQubits]
        })),
        ...Array.from({ length: inputQubits }, (_, i) => ({
          type: 'H' as const,
          target: i
        })),
      ]
    };
  }

  public encode(inputData: number[]): number[] {
    const state = this.simulator.executeCircuit(this.encoderCircuit, inputData);
    return this.simulator.measureState(state);
  }

  public decode(encodedData: number[]): number[] {
    const state = this.simulator.executeCircuit(this.decoderCircuit, encodedData);
    return this.simulator.measureState(state);
  }

  public trainStep(trainingData: number[][]): number {
    let totalError = 0;
    const gradients = new Array(this.parameters.length).fill(0);
    const learningRate = 0.01;
    const epsilon = 1e-8; // Small value for numerical gradient

    for (const sample of trainingData) {
      const encoded = this.encode(sample);
      const reconstructed = this.decode(encoded);
      const error = this.simulator.calculateReconstructionError(sample, reconstructed);
      totalError += error;

      // Calculate numerical gradients for each parameter
      for (let i = 0; i < this.parameters.length; i++) {
        // Positive perturbation
        this.parameters[i] += epsilon;
        const encodedPos = this.encode(sample);
        const reconstructedPos = this.decode(encodedPos);
        const errorPos = this.simulator.calculateReconstructionError(sample, reconstructedPos);

        // Negative perturbation
        this.parameters[i] -= 2 * epsilon;
        const encodedNeg = this.encode(sample);
        const reconstructedNeg = this.decode(encodedNeg);
        const errorNeg = this.simulator.calculateReconstructionError(sample, reconstructedNeg);

        // Restore original parameter
        this.parameters[i] += epsilon;

        // Calculate gradient
        gradients[i] += (errorPos - errorNeg) / (2 * epsilon);
      }
    }

    // Update parameters using averaged gradients
    for (let i = 0; i < this.parameters.length; i++) {
      gradients[i] /= trainingData.length;
      this.parameters[i] -= learningRate * gradients[i];
      
      // Keep parameters in reasonable range
      this.parameters[i] = Math.max(-2 * Math.PI, Math.min(2 * Math.PI, this.parameters[i]));
    }

    // Update circuit parameters
    this.updateCircuitParameters();
    
    return totalError / trainingData.length;
  }

  private updateCircuitParameters(): void {
    // Update encoder circuit parameters
    for (let i = 0; i < this.encoderCircuit.gates.length; i++) {
      const gate = this.encoderCircuit.gates[i];
      if (gate.type === 'RY' && gate.target < this.parameters.length) {
        gate.parameter = this.parameters[gate.target];
      }
    }

    // Update decoder circuit parameters  
    for (let i = 0; i < this.decoderCircuit.gates.length; i++) {
      const gate = this.decoderCircuit.gates[i];
      if (gate.type === 'RY' && gate.target < this.parameters.length) {
        const inputQubits = this.encoderCircuit.qubits;
        gate.parameter = -this.parameters[gate.target + inputQubits];
      }
    }
  }

  public detectAnomaly(inputData: number[], threshold: number = 0.12): { isAnomaly: boolean; error: number; confidence: number } {
    const encoded = this.encode(inputData);
    const reconstructed = this.decode(encoded);
    const error = this.simulator.calculateReconstructionError(inputData, reconstructed);
    
    const isAnomaly = error > threshold;
    const confidence = Math.min(1, Math.max(0, (error - threshold) / threshold + 0.5));
    
    return { isAnomaly, error, confidence };
  }

  public getParameters(): number[] {
    return [...this.parameters];
  }

  public setParameters(params: number[]): void {
    this.parameters = [...params];
    this.updateCircuitParameters();
  }
}
