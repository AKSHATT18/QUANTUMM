import { QuantumAutoencoder } from './quantumSimulator';
import { type Transaction, type FraudAlert } from '@shared/schema';

export interface FraudDetectionResult {
  transactionId: string;
  riskScore: number;
  isAnomaly: boolean;
  quantumConfidence: number;
  features: number[];
  reconstructionError: number;
  alertType?: string;
  description?: string;
}

export interface TransactionFeatures {
  amount: number;
  timeOfDay: number;
  dayOfWeek: number;
  merchantCategory: number;
  geographicRisk: number;
  velocityScore: number;
  accountAge: number;
  historicalPattern: number;
}

export class FraudDetectionEngine {
  private quantumModel: QuantumAutoencoder;
  private featureNormalizers: Map<string, { min: number; max: number }> = new Map();
  private alertThresholds = {
    low: 0.3,
    medium: 0.6,
    high: 0.8,
    critical: 0.9
  };

  constructor() {
    this.quantumModel = new QuantumAutoencoder(8, 4); // 8 input features, 4 encoded qubits
    this.initializeFeatureNormalizers();
  }

  private initializeFeatureNormalizers(): void {
    // Initialize with typical transaction ranges
    this.featureNormalizers.set('amount', { min: 0, max: 100000 });
    this.featureNormalizers.set('timeOfDay', { min: 0, max: 24 });
    this.featureNormalizers.set('dayOfWeek', { min: 0, max: 7 });
    this.featureNormalizers.set('merchantCategory', { min: 0, max: 10 });
    this.featureNormalizers.set('geographicRisk', { min: 0, max: 1 });
    this.featureNormalizers.set('velocityScore', { min: 0, max: 1 });
    this.featureNormalizers.set('accountAge', { min: 0, max: 365 });
    this.featureNormalizers.set('historicalPattern', { min: 0, max: 1 });
  }

  public extractFeatures(transaction: Transaction): TransactionFeatures {
    const timestamp = new Date(transaction.timestamp);
    const timeOfDay = timestamp.getHours() + timestamp.getMinutes() / 60;
    const dayOfWeek = timestamp.getDay();

    // Extract features from transaction
    return {
      amount: transaction.amount,
      timeOfDay,
      dayOfWeek,
      merchantCategory: this.getMerchantCategory(transaction.toAccount),
      geographicRisk: this.calculateGeographicRisk(transaction),
      velocityScore: this.calculateVelocityScore(transaction),
      accountAge: this.getAccountAge(transaction.fromAccount),
      historicalPattern: this.getHistoricalPattern(transaction)
    };
  }

  private getMerchantCategory(account: string): number {
    // Simulate merchant category extraction
    const hash = this.simpleHash(account);
    return hash % 10;
  }

  private calculateGeographicRisk(transaction: Transaction): number {
    // Simulate geographic risk calculation
    const hash = this.simpleHash(transaction.fromAccount + transaction.toAccount);
    return (hash % 100) / 100;
  }

  private calculateVelocityScore(transaction: Transaction): number {
    // Simulate velocity scoring (frequency of transactions)
    const hash = this.simpleHash(transaction.fromAccount);
    return Math.min(1, (hash % 20) / 20);
  }

  private getAccountAge(account: string): number {
    // Simulate account age in days
    const hash = this.simpleHash(account);
    return hash % 365;
  }

  private getHistoricalPattern(transaction: Transaction): number {
    // Simulate historical pattern analysis
    const hash = this.simpleHash(transaction.fromAccount + transaction.amount.toString());
    return (hash % 100) / 100;
  }

  private simpleHash(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }

  private normalizeFeatures(features: TransactionFeatures): number[] {
    const normalized: number[] = [];
    
    for (const [key, value] of Object.entries(features)) {
      const normalizer = this.featureNormalizers.get(key);
      if (normalizer) {
        const normalizedValue = (value - normalizer.min) / (normalizer.max - normalizer.min);
        normalized.push(Math.max(0, Math.min(1, normalizedValue)));
      }
    }
    
    return normalized;
  }

  public detectFraud(transaction: Transaction): FraudDetectionResult {
    // Extract and normalize features
    const features = this.extractFeatures(transaction);
    const normalizedFeatures = this.normalizeFeatures(features);

    // Use quantum autoencoder for anomaly detection
    const anomalyResult = this.quantumModel.detectAnomaly(normalizedFeatures);
    
    // Calculate risk score based on multiple factors
    const riskScore = this.calculateRiskScore(features, anomalyResult);
    
    // Determine alert type and description
    const alertInfo = this.generateAlertInfo(riskScore, features, anomalyResult);

    return {
      transactionId: transaction.id,
      riskScore,
      isAnomaly: anomalyResult.isAnomaly,
      quantumConfidence: anomalyResult.confidence,
      features: normalizedFeatures,
      reconstructionError: anomalyResult.error,
      alertType: alertInfo.type,
      description: alertInfo.description
    };
  }

  private calculateRiskScore(features: TransactionFeatures, anomalyResult: any): number {
    let riskScore = anomalyResult.error; // Base score from quantum model

    // Adjust based on transaction characteristics
    if (features.amount > 10000) riskScore += 0.1; // Large amounts
    if (features.timeOfDay < 6 || features.timeOfDay > 22) riskScore += 0.05; // Unusual hours
    if (features.geographicRisk > 0.7) riskScore += 0.15; // High geographic risk
    if (features.velocityScore > 0.8) riskScore += 0.1; // High velocity
    if (features.accountAge < 30) riskScore += 0.05; // New account

    return Math.max(0, Math.min(1, riskScore));
  }

  private generateAlertInfo(riskScore: number, features: TransactionFeatures, anomalyResult: any): { type: string; description: string } {
    if (riskScore >= this.alertThresholds.critical) {
      return {
        type: "critical_risk",
        description: `Critical fraud risk detected: High reconstruction error (${anomalyResult.error.toFixed(4)}) with unusual transaction pattern`
      };
    } else if (riskScore >= this.alertThresholds.high) {
      if (features.amount > 20000) {
        return {
          type: "high_value_risk",
          description: `High-value transaction ($${features.amount.toLocaleString()}) with suspicious characteristics`
        };
      } else if (features.velocityScore > 0.8) {
        return {
          type: "suspicious_velocity",
          description: "Multiple rapid transactions detected from same account"
        };
      } else {
        return {
          type: "high_risk",
          description: "High fraud probability based on quantum pattern analysis"
        };
      }
    } else if (riskScore >= this.alertThresholds.medium) {
      return {
        type: "medium_risk",
        description: "Moderate fraud risk - requires manual review"
      };
    } else if (riskScore >= this.alertThresholds.low) {
      return {
        type: "low_risk",
        description: "Low fraud probability - monitoring recommended"
      };
    } else {
      return {
        type: "normal",
        description: "Transaction appears normal"
      };
    }
  }

  public trainModel(transactions: Transaction[]): { epochs: number; finalError: number; accuracy: number } {
    // Extract features from training data
    const trainingData = transactions.map(tx => {
      const features = this.extractFeatures(tx);
      return this.normalizeFeatures(features);
    });

    // Train quantum autoencoder
    let epochs = 0;
    let finalError = 0;
    const maxEpochs = 100;

    for (let epoch = 0; epoch < maxEpochs; epoch++) {
      finalError = this.quantumModel.trainStep(trainingData);
      epochs++;
      
      // Early stopping if error is low enough
      if (finalError < 0.05) break;
    }

    // Calculate accuracy on training data
    let correct = 0;
    for (const tx of transactions) {
      const result = this.detectFraud(tx);
      const actualFraud = tx.isFraud || false;
      const predictedFraud = result.riskScore > 0.5;
      
      if (actualFraud === predictedFraud) {
        correct++;
      }
    }

    const accuracy = correct / transactions.length;

    return { epochs, finalError, accuracy };
  }

  public updateModel(parameters: number[]): void {
    this.quantumModel.setParameters(parameters);
  }

  public getModelParameters(): number[] {
    return this.quantumModel.getParameters();
  }

  public getModelMetrics(): { accuracy: number; precision: number; recall: number; f1Score: number; falsePositiveRate: number } {
    // In a real implementation, these would be calculated from validation data
    return {
      accuracy: 0.924,
      precision: 0.92,
      recall: 0.89,
      f1Score: 0.88,
      falsePositiveRate: 0.032
    };
  }
}
