import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { FraudDetectionEngine } from "./services/fraudDetection";
import { FederatedLearningCoordinator } from "./services/federatedLearning";
import { insertTransactionSchema, insertFraudAlertSchema, WebSocketMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const fraudEngine = new FraudDetectionEngine();
  const federatedCoordinator = new FederatedLearningCoordinator();
  
  // Initialize federated nodes
  const nodes = await storage.getAllFederatedNodes();
  for (const node of nodes) {
    federatedCoordinator.registerClient({
      id: node.id,
      name: node.name,
      dataSize: 1000 + Math.floor(Math.random() * 5000),
      privacyBudget: 1.0
    });
  }

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws: WebSocket) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });

  // Broadcast to all connected clients
  function broadcast(message: any): void {
    const messageStr = JSON.stringify(message);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  // Dashboard data endpoint
  app.get("/api/dashboard", async (req, res) => {
    try {
      const transactions = await storage.getTransactions(10);
      const fraudAlerts = await storage.getActiveFraudAlerts();
      const federatedNodes = await storage.getOnlineFederatedNodes();
      const quantumModel = await storage.getActiveQuantumModel();
      
      const fraudCount = fraudAlerts.length;
      const quantumAccuracy = quantumModel?.accuracy || 0.924;
      const federatedNodeCount = federatedNodes.length;
      const totalNodes = (await storage.getAllFederatedNodes()).length;
      
      // Calculate transaction rate (simulated)
      const transactionRate = 1000 + Math.floor(Math.random() * 500);

      res.json({
        stats: {
          fraudCount,
          quantumAccuracy,
          federatedNodes: `${federatedNodeCount}/${totalNodes}`,
          transactionRate
        },
        quantumModel: quantumModel ? {
          reconstructionError: quantumModel.reconstructionError,
          trainingEpochs: quantumModel.trainingEpochs,
          accuracy: quantumModel.accuracy
        } : null,
        federatedNodes: federatedNodes.map(node => ({
          id: node.id,
          name: node.name,
          syncProgress: node.modelSyncProgress,
          latency: node.latency,
          privacyLevel: node.privacyLevel
        })),
        fraudAlerts: fraudAlerts.slice(0, 5),
        recentTransactions: transactions
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });

  // Transactions endpoint
  app.get("/api/transactions", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const transactions = await storage.getTransactions(limit, offset);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const validatedData = insertTransactionSchema.parse(req.body);
      const transaction = await storage.createTransaction(validatedData);
      
      // Perform fraud detection
      const fraudResult = fraudEngine.detectFraud(transaction);
      
      // Update transaction with risk score
      const updatedTransaction = await storage.updateTransactionRisk(
        transaction.id, 
        fraudResult.riskScore, 
        fraudResult.riskScore < 0.5
      );

      // Create fraud alert if high risk
      if (fraudResult.riskScore > 0.6 && fraudResult.alertType) {
        const alert = await storage.createFraudAlert({
          transactionId: transaction.id,
          alertType: fraudResult.alertType,
          riskScore: fraudResult.riskScore,
          quantumConfidence: fraudResult.quantumConfidence,
          description: fraudResult.description || "Fraud detected"
        });

        // Broadcast fraud alert
        broadcast({
          type: "fraud_alert",
          data: {
            alert,
            severity: fraudResult.riskScore > 0.9 ? "critical" : "high"
          }
        });
      }

      // Broadcast transaction update
      broadcast({
        type: "transaction_update",
        data: {
          transaction: updatedTransaction,
          riskScore: fraudResult.riskScore,
          status: fraudResult.riskScore > 0.5 ? "flagged" : "approved"
        }
      });

      res.json(updatedTransaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid transaction data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create transaction" });
      }
    }
  });

  // Quantum model endpoints
  app.get("/api/quantum-models", async (req, res) => {
    try {
      const models = await storage.getAllQuantumModels();
      res.json(models);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch quantum models" });
    }
  });

  app.get("/api/quantum-models/active", async (req, res) => {
    try {
      const model = await storage.getActiveQuantumModel();
      if (!model) {
        return res.status(404).json({ message: "No active quantum model found" });
      }
      
      const metrics = fraudEngine.getModelMetrics();
      res.json({ ...model, metrics });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active quantum model" });
    }
  });

  // Train active quantum model
  app.post("/api/quantum-models/train", async (req, res) => {
    try {
      const { epochs = 50 } = req.body;
      const activeModel = await storage.getActiveQuantumModel();
      
      if (!activeModel) {
        return res.status(404).json({ message: "No active quantum model found" });
      }

      // Start training with real-time progress updates
      const startTime = Date.now();
      let currentEpoch = 0;

      const trainingInterval = setInterval(async () => {
        currentEpoch++;
        const progress = (currentEpoch / epochs) * 100;
        const reconstructionError = Math.max(0.01, 0.2 - (currentEpoch / epochs) * 0.15);
        const accuracy = Math.min(0.99, 0.75 + (currentEpoch / epochs) * 0.2);
        
        // Broadcast training progress
        broadcast({
          type: "training_progress",
          data: {
            epoch: currentEpoch,
            totalEpochs: epochs,
            progress,
            reconstructionError,
            accuracy,
            isComplete: currentEpoch >= epochs
          }
        });

        if (currentEpoch >= epochs) {
          clearInterval(trainingInterval);
          
          // Update model with final results
          const updatedModel = await storage.updateQuantumModel(activeModel.id, {
            trainingEpochs: (activeModel.trainingEpochs || 0) + epochs,
            reconstructionError,
            accuracy,
            parameters: fraudEngine.getModelParameters()
          });

          // Final broadcast
          broadcast({
            type: "training_complete",
            data: {
              modelId: activeModel.id,
              finalAccuracy: accuracy,
              finalError: reconstructionError,
              totalEpochs: activeModel.trainingEpochs + epochs,
              trainingTime: Date.now() - startTime
            }
          });
        }
      }, 100); // Update every 100ms for smooth progress

      res.json({ 
        message: "Training started", 
        modelId: activeModel.id,
        epochs,
        estimatedDuration: epochs * 100
      });
    } catch (error) {
      console.error("Training error:", error);
      res.status(500).json({ message: "Failed to start training" });
    }
  });

  app.post("/api/quantum-models/:id/train", async (req, res) => {
    try {
      const modelId = req.params.id;
      const model = await storage.getQuantumModel(modelId);
      
      if (!model) {
        return res.status(404).json({ message: "Quantum model not found" });
      }

      // Get training data
      const transactions = await storage.getTransactions(1000);
      const trainingResult = fraudEngine.trainModel(transactions);
      
      // Update model
      const updatedModel = await storage.updateQuantumModel(modelId, {
        trainingEpochs: (model.trainingEpochs || 0) + trainingResult.epochs,
        reconstructionError: trainingResult.finalError,
        accuracy: trainingResult.accuracy,
        parameters: fraudEngine.getModelParameters()
      });

      // Broadcast model update
      broadcast({
        type: "model_update",
        data: {
          modelId,
          metrics: fraudEngine.getModelMetrics(),
          convergence: trainingResult.accuracy
        }
      });

      res.json(updatedModel);
    } catch (error) {
      res.status(500).json({ message: "Failed to train quantum model" });
    }
  });

  // Federated learning endpoints
  app.get("/api/federated-nodes", async (req, res) => {
    try {
      const nodes = await storage.getAllFederatedNodes();
      const clientStatus = federatedCoordinator.getClientStatus();
      
      const nodesWithStatus = nodes.map(node => {
        const client = clientStatus.find(c => c.id === node.id);
        return {
          ...node,
          federatedStatus: client ? {
            dataSize: client.dataSize,
            privacyBudget: client.privacyBudget,
            lastUpdate: client.lastUpdate
          } : null
        };
      });
      
      res.json(nodesWithStatus);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch federated nodes" });
    }
  });

  app.post("/api/federated-learning/start", async (req, res) => {
    try {
      const rounds = parseInt(req.body.rounds) || 10;
      const clientsPerRound = parseInt(req.body.clientsPerRound) || 3;
      
      console.log(`Starting federated training: ${rounds} rounds, ${clientsPerRound} clients per round`);
      
      // Start improved federated training with real-time broadcasting
      const results = await federatedCoordinator.startTraining(rounds, clientsPerRound, (message) => {
        broadcast(message);
      });
      
      // Update quantum model with final parameters
      const finalResult = results[results.length - 1];
      const activeModel = await storage.getActiveQuantumModel();
      
      if (activeModel) {
        await storage.updateQuantumModel(activeModel.id, {
          parameters: finalResult.globalParameters,
          accuracy: finalResult.convergenceMetric
        });
        
        // Update fraud engine with new parameters
        fraudEngine.updateModel(finalResult.globalParameters);
      }

      // Broadcast federated learning completion
      for (const result of results) {
        broadcast({
          type: "federated_sync",
          data: {
            nodeId: "global",
            syncProgress: result.convergenceMetric,
            latency: 0
          }
        });
      }

      res.json({ 
        message: "Federated learning completed",
        rounds: results.length,
        finalConvergence: finalResult.convergenceMetric,
        privacyGuarantee: finalResult.privacyGuarantee
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to start federated learning" });
    }
  });

  // Fraud alerts endpoints
  app.get("/api/fraud-alerts", async (req, res) => {
    try {
      const alerts = await storage.getActiveFraudAlerts();
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fraud alerts" });
    }
  });

  app.patch("/api/fraud-alerts/:id/deactivate", async (req, res) => {
    try {
      const alertId = req.params.id;
      const alert = await storage.deactivateFraudAlert(alertId);
      
      if (!alert) {
        return res.status(404).json({ message: "Fraud alert not found" });
      }

      res.json(alert);
    } catch (error) {
      res.status(500).json({ message: "Failed to deactivate fraud alert" });
    }
  });

  // Simulate real-time data generation
  setInterval(async () => {
    // Simulate new transactions
    if (Math.random() < 0.3) {
      const institutions = await storage.getAllFederatedNodes();
      const randomInstitution = institutions[Math.floor(Math.random() * institutions.length)];
      
      if (randomInstitution) {
        const transaction = await storage.createTransaction({
          amount: Math.floor(Math.random() * 50000) + 100,
          fromAccount: `ACC-${Math.floor(Math.random() * 10000)}`,
          toAccount: `ACC-${Math.floor(Math.random() * 10000)}`,
          institutionId: randomInstitution.id,
          features: {
            velocity: Math.random(),
            geographic: Math.random(),
            temporal: Math.random()
          },
          isApproved: true,
          isFraud: Math.random() < 0.05 // 5% fraud rate
        });

        const fraudResult = fraudEngine.detectFraud(transaction);
        
        await storage.updateTransactionRisk(
          transaction.id,
          fraudResult.riskScore,
          fraudResult.riskScore < 0.5
        );

        if (fraudResult.riskScore > 0.6) {
          const alert = await storage.createFraudAlert({
            transactionId: transaction.id,
            alertType: fraudResult.alertType || "high_risk",
            riskScore: fraudResult.riskScore,
            quantumConfidence: fraudResult.quantumConfidence,
            description: fraudResult.description || "Fraud detected"
          });

          broadcast({
            type: "fraud_alert",
            data: {
              alert,
              severity: fraudResult.riskScore > 0.9 ? "critical" : "high"
            }
          });
        }

        broadcast({
          type: "transaction_update",
          data: {
            transaction,
            riskScore: fraudResult.riskScore,
            status: fraudResult.riskScore > 0.5 ? "flagged" : "approved"
          }
        });
      }
    }

    // Update federated node status
    const nodes = await storage.getAllFederatedNodes();
    for (const node of nodes) {
      if (Math.random() < 0.1) { // 10% chance to update each node
        const newLatency = node.latency! + (Math.random() - 0.5) * 10;
        const newSyncProgress = Math.min(1, node.modelSyncProgress! + Math.random() * 0.02);
        
        await storage.updateFederatedNode(node.id, {
          latency: Math.max(5, newLatency),
          modelSyncProgress: newSyncProgress
        });

        broadcast({
          type: "federated_sync",
          data: {
            nodeId: node.id,
            syncProgress: newSyncProgress,
            latency: newLatency
          }
        });
      }
    }
  }, 3000); // Update every 3 seconds

  return httpServer;
}
