import { type User, type InsertUser, type Transaction, type InsertTransaction, 
         type QuantumModel, type InsertQuantumModel, type FederatedNode, 
         type InsertFederatedNode, type FraudAlert, type InsertFraudAlert,
         type ModelMetrics, type InsertModelMetrics } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Transaction methods
  getTransaction(id: string): Promise<Transaction | undefined>;
  getTransactions(limit?: number, offset?: number): Promise<Transaction[]>;
  getTransactionsByInstitution(institutionId: string): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionRisk(id: string, riskScore: number, isApproved: boolean): Promise<Transaction | undefined>;

  // Quantum model methods
  getQuantumModel(id: string): Promise<QuantumModel | undefined>;
  getActiveQuantumModel(): Promise<QuantumModel | undefined>;
  getAllQuantumModels(): Promise<QuantumModel[]>;
  createQuantumModel(model: InsertQuantumModel): Promise<QuantumModel>;
  updateQuantumModel(id: string, updates: Partial<QuantumModel>): Promise<QuantumModel | undefined>;

  // Federated node methods
  getFederatedNode(id: string): Promise<FederatedNode | undefined>;
  getAllFederatedNodes(): Promise<FederatedNode[]>;
  getOnlineFederatedNodes(): Promise<FederatedNode[]>;
  createFederatedNode(node: InsertFederatedNode): Promise<FederatedNode>;
  updateFederatedNode(id: string, updates: Partial<FederatedNode>): Promise<FederatedNode | undefined>;

  // Fraud alert methods
  getFraudAlert(id: string): Promise<FraudAlert | undefined>;
  getActiveFraudAlerts(): Promise<FraudAlert[]>;
  getFraudAlertsByTransaction(transactionId: string): Promise<FraudAlert[]>;
  createFraudAlert(alert: InsertFraudAlert): Promise<FraudAlert>;
  deactivateFraudAlert(id: string): Promise<FraudAlert | undefined>;

  // Model metrics methods
  getModelMetrics(modelId: string, limit?: number): Promise<ModelMetrics[]>;
  createModelMetrics(metrics: InsertModelMetrics): Promise<ModelMetrics>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private transactions: Map<string, Transaction> = new Map();
  private quantumModels: Map<string, QuantumModel> = new Map();
  private federatedNodes: Map<string, FederatedNode> = new Map();
  private fraudAlerts: Map<string, FraudAlert> = new Map();
  private modelMetrics: Map<string, ModelMetrics> = new Map();

  constructor() {
    this.initializeTestData();
  }

  private initializeTestData(): void {
    // Initialize some test federated nodes
    const testNodes: FederatedNode[] = [
      {
        id: randomUUID(),
        name: "Bank Alpha",
        institutionType: "Commercial Bank",
        isOnline: true,
        modelSyncProgress: 0.98,
        latency: 24,
        privacyLevel: 0.997,
        lastSeen: new Date()
      },
      {
        id: randomUUID(),
        name: "Credit Union Beta",
        institutionType: "Credit Union",
        isOnline: true,
        modelSyncProgress: 0.94,
        latency: 31,
        privacyLevel: 0.995,
        lastSeen: new Date()
      },
      {
        id: randomUUID(),
        name: "FinTech Gamma",
        institutionType: "FinTech",
        isOnline: true,
        modelSyncProgress: 0.96,
        latency: 18,
        privacyLevel: 0.998,
        lastSeen: new Date()
      }
    ];

    testNodes.forEach(node => this.federatedNodes.set(node.id, node));

    // Initialize a test quantum model
    const testModel: QuantumModel = {
      id: randomUUID(),
      name: "Quantum Fraud Autoencoder v1.0",
      architecture: {
        qubits: 8,
        gates: ["H", "RY", "RZ", "CNOT"],
        layers: 4
      },
      parameters: Array.from({ length: 32 }, () => Math.random() * 2 * Math.PI),
      trainingEpochs: 247,
      reconstructionError: 0.0847,
      accuracy: 0.924,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    this.quantumModels.set(testModel.id, testModel);
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Transaction methods
  async getTransaction(id: string): Promise<Transaction | undefined> {
    return this.transactions.get(id);
  }

  async getTransactions(limit: number = 50, offset: number = 0): Promise<Transaction[]> {
    const allTransactions = Array.from(this.transactions.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return allTransactions.slice(offset, offset + limit);
  }

  async getTransactionsByInstitution(institutionId: string): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(tx => tx.institutionId === institutionId);
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const transaction: Transaction = {
      ...insertTransaction,
      id,
      timestamp: new Date(),
      riskScore: null,
      isApproved: insertTransaction.isApproved ?? true,
      isFraud: insertTransaction.isFraud ?? false,
    };
    this.transactions.set(id, transaction);
    return transaction;
  }

  async updateTransactionRisk(id: string, riskScore: number, isApproved: boolean): Promise<Transaction | undefined> {
    const transaction = this.transactions.get(id);
    if (transaction) {
      transaction.riskScore = riskScore;
      transaction.isApproved = isApproved;
      this.transactions.set(id, transaction);
    }
    return transaction;
  }

  // Quantum model methods
  async getQuantumModel(id: string): Promise<QuantumModel | undefined> {
    return this.quantumModels.get(id);
  }

  async getActiveQuantumModel(): Promise<QuantumModel | undefined> {
    return Array.from(this.quantumModels.values()).find(model => model.isActive);
  }

  async getAllQuantumModels(): Promise<QuantumModel[]> {
    return Array.from(this.quantumModels.values());
  }

  async createQuantumModel(insertModel: InsertQuantumModel): Promise<QuantumModel> {
    const id = randomUUID();
    const model: QuantumModel = {
      ...insertModel,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
      isActive: insertModel.isActive ?? false,
      trainingEpochs: insertModel.trainingEpochs ?? 0,
      reconstructionError: insertModel.reconstructionError ?? null,
      accuracy: insertModel.accuracy ?? null,
    };
    this.quantumModels.set(id, model);
    return model;
  }

  async updateQuantumModel(id: string, updates: Partial<QuantumModel>): Promise<QuantumModel | undefined> {
    const model = this.quantumModels.get(id);
    if (model) {
      const updatedModel = { ...model, ...updates, updatedAt: new Date() };
      this.quantumModels.set(id, updatedModel);
      return updatedModel;
    }
    return undefined;
  }

  // Federated node methods
  async getFederatedNode(id: string): Promise<FederatedNode | undefined> {
    return this.federatedNodes.get(id);
  }

  async getAllFederatedNodes(): Promise<FederatedNode[]> {
    return Array.from(this.federatedNodes.values());
  }

  async getOnlineFederatedNodes(): Promise<FederatedNode[]> {
    return Array.from(this.federatedNodes.values()).filter(node => node.isOnline);
  }

  async createFederatedNode(insertNode: InsertFederatedNode): Promise<FederatedNode> {
    const id = randomUUID();
    const node: FederatedNode = {
      ...insertNode,
      id,
      lastSeen: new Date(),
      isOnline: insertNode.isOnline ?? false,
      modelSyncProgress: insertNode.modelSyncProgress ?? 0,
      latency: insertNode.latency ?? null,
      privacyLevel: insertNode.privacyLevel ?? 0.997,
    };
    this.federatedNodes.set(id, node);
    return node;
  }

  async updateFederatedNode(id: string, updates: Partial<FederatedNode>): Promise<FederatedNode | undefined> {
    const node = this.federatedNodes.get(id);
    if (node) {
      const updatedNode = { ...node, ...updates, lastSeen: new Date() };
      this.federatedNodes.set(id, updatedNode);
      return updatedNode;
    }
    return undefined;
  }

  // Fraud alert methods
  async getFraudAlert(id: string): Promise<FraudAlert | undefined> {
    return this.fraudAlerts.get(id);
  }

  async getActiveFraudAlerts(): Promise<FraudAlert[]> {
    return Array.from(this.fraudAlerts.values())
      .filter(alert => alert.isActive)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getFraudAlertsByTransaction(transactionId: string): Promise<FraudAlert[]> {
    return Array.from(this.fraudAlerts.values())
      .filter(alert => alert.transactionId === transactionId);
  }

  async createFraudAlert(insertAlert: InsertFraudAlert): Promise<FraudAlert> {
    const id = randomUUID();
    const alert: FraudAlert = {
      ...insertAlert,
      id,
      createdAt: new Date(),
      isActive: insertAlert.isActive ?? true,
    };
    this.fraudAlerts.set(id, alert);
    return alert;
  }

  async deactivateFraudAlert(id: string): Promise<FraudAlert | undefined> {
    const alert = this.fraudAlerts.get(id);
    if (alert) {
      alert.isActive = false;
      this.fraudAlerts.set(id, alert);
    }
    return alert;
  }

  // Model metrics methods
  async getModelMetrics(modelId: string, limit: number = 10): Promise<ModelMetrics[]> {
    return Array.from(this.modelMetrics.values())
      .filter(metrics => metrics.modelId === modelId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
  }

  async createModelMetrics(insertMetrics: InsertModelMetrics): Promise<ModelMetrics> {
    const id = randomUUID();
    const metrics: ModelMetrics = {
      ...insertMetrics,
      id,
      timestamp: new Date(),
    };
    this.modelMetrics.set(id, metrics);
    return metrics;
  }
}

export const storage = new MemStorage();
