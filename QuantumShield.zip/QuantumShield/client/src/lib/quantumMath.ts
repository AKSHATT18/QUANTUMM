// Client-side quantum mathematics utilities for visualization

export interface QuantumStateVisualization {
  amplitudes: { real: number; imaginary: number; probability: number }[];
  phase: number[];
  entanglement: number;
}

export interface CircuitGateVisualization {
  type: string;
  target: number;
  control?: number;
  parameter?: number;
  matrix?: number[][];
}

export class QuantumMathUtils {
  static complexMagnitude(real: number, imaginary: number): number {
    return Math.sqrt(real * real + imaginary * imaginary);
  }

  static complexPhase(real: number, imaginary: number): number {
    return Math.atan2(imaginary, real);
  }

  static probabilityFromAmplitude(real: number, imaginary: number): number {
    return real * real + imaginary * imaginary;
  }

  static generateQuantumStateVisualization(
    numQubits: number = 3,
    parameters: number[] = []
  ): QuantumStateVisualization {
    const numStates = Math.pow(2, numQubits);
    const amplitudes = [];
    
    // Generate quantum state amplitudes based on parameters
    for (let i = 0; i < numStates; i++) {
      const parameterIndex = i % parameters.length;
      const phase = parameters[parameterIndex] || Math.random() * 2 * Math.PI;
      
      const magnitude = Math.random() * 0.5 + 0.1; // Random magnitude for visualization
      const real = magnitude * Math.cos(phase);
      const imaginary = magnitude * Math.sin(phase);
      const probability = this.probabilityFromAmplitude(real, imaginary);
      
      amplitudes.push({ real, imaginary, probability });
    }
    
    // Normalize probabilities
    const totalProbability = amplitudes.reduce((sum, amp) => sum + amp.probability, 0);
    amplitudes.forEach(amp => {
      amp.probability /= totalProbability;
    });
    
    // Calculate phases
    const phase = amplitudes.map(amp => this.complexPhase(amp.real, amp.imaginary));
    
    // Calculate entanglement measure (simplified)
    const entanglement = this.calculateEntanglementMeasure(amplitudes);
    
    return { amplitudes, phase, entanglement };
  }

  private static calculateEntanglementMeasure(amplitudes: any[]): number {
    // Simplified entanglement measure for visualization
    const variance = amplitudes.reduce((sum, amp, i) => {
      const mean = 1 / amplitudes.length;
      return sum + Math.pow(amp.probability - mean, 2);
    }, 0) / amplitudes.length;
    
    return Math.min(1, variance * 10); // Scale for visualization
  }

  static generateHadamardMatrix(): number[][] {
    const sqrt2 = Math.sqrt(2);
    return [
      [1/sqrt2, 1/sqrt2],
      [1/sqrt2, -1/sqrt2]
    ];
  }

  static generateRotationYMatrix(theta: number): number[][] {
    const cosHalf = Math.cos(theta / 2);
    const sinHalf = Math.sin(theta / 2);
    return [
      [cosHalf, -sinHalf],
      [sinHalf, cosHalf]
    ];
  }

  static generatePauliXMatrix(): number[][] {
    return [
      [0, 1],
      [1, 0]
    ];
  }

  static getGateColor(gateType: string): string {
    const colorMap: Record<string, string> = {
      'H': 'hsl(159, 64%, 41%)', // accent
      'X': 'hsl(0, 86%, 59%)', // destructive  
      'Y': 'hsl(262, 83%, 58%)', // chart-5
      'Z': 'hsl(343, 75%, 59%)', // chart-4
      'RY': 'hsl(38, 92%, 50%)', // chart-3
      'RZ': 'hsl(38, 92%, 50%)', // chart-3
      'RX': 'hsl(38, 92%, 50%)', // chart-3
      'CNOT': 'hsl(217, 91%, 60%)', // primary
      'CZ': 'hsl(217, 91%, 60%)', // primary
      'M': 'hsl(0, 86%, 59%)', // destructive (measurement)
    };
    
    return colorMap[gateType] || 'hsl(215, 20%, 65%)'; // muted-foreground as fallback
  }

  static formatComplex(real: number, imaginary: number): string {
    const roundedReal = Math.round(real * 1000) / 1000;
    const roundedImag = Math.round(imaginary * 1000) / 1000;
    
    if (Math.abs(roundedImag) < 0.001) {
      return `${roundedReal}`;
    }
    
    if (Math.abs(roundedReal) < 0.001) {
      return `${roundedImag}i`;
    }
    
    const sign = roundedImag >= 0 ? '+' : '-';
    return `${roundedReal} ${sign} ${Math.abs(roundedImag)}i`;
  }

  static calculateBlochSphereCoordinates(real: number, imaginary: number): { x: number; y: number; z: number } {
    const magnitude = this.complexMagnitude(real, imaginary);
    const phase = this.complexPhase(real, imaginary);
    
    // Convert to Bloch sphere coordinates (simplified for visualization)
    const theta = 2 * Math.acos(magnitude);
    const phi = phase;
    
    return {
      x: Math.sin(theta) * Math.cos(phi),
      y: Math.sin(theta) * Math.sin(phi),
      z: Math.cos(theta)
    };
  }

  static interpolateQuantumStates(
    state1: QuantumStateVisualization, 
    state2: QuantumStateVisualization, 
    t: number
  ): QuantumStateVisualization {
    const amplitudes = state1.amplitudes.map((amp1, i) => {
      const amp2 = state2.amplitudes[i];
      return {
        real: amp1.real * (1 - t) + amp2.real * t,
        imaginary: amp1.imaginary * (1 - t) + amp2.imaginary * t,
        probability: amp1.probability * (1 - t) + amp2.probability * t,
      };
    });
    
    const phase = state1.phase.map((p1, i) => {
      const p2 = state2.phase[i];
      return p1 * (1 - t) + p2 * t;
    });
    
    const entanglement = state1.entanglement * (1 - t) + state2.entanglement * t;
    
    return { amplitudes, phase, entanglement };
  }
}
