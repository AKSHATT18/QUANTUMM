import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/Sidebar";
import FederatedNetworkStatus from "@/components/FederatedNetworkStatus";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Network, Play, Pause, Users, Shield, Zap, Globe, Activity } from "lucide-react";
import { useWebSocket } from "@/hooks/useWebSocket";
import { useToast } from "@/hooks/use-toast";

interface FederatedNode {
  id: string;
  name: string;
  institutionType: string;
  isOnline: boolean;
  modelSyncProgress: number;
  latency: number;
  privacyLevel: number;
  lastSeen: string;
}

interface TrainingProgress {
  round: number;
  totalRounds: number;
  convergence: number;
  participatingClients: number;
  globalAccuracy: number;
  reconstructionError: number;
  privacyBudget: number;
}

export default function FederatedNetwork() {
  const [isTraining, setIsTraining] = useState(false);
  const [trainingProgress, setTrainingProgress] = useState<TrainingProgress | null>(null);
  const { toast } = useToast();
  const { subscribe } = useWebSocket();

  const { data: nodes = [], isLoading, refetch } = useQuery<FederatedNode[]>({
    queryKey: ["/api/federated-nodes"],
    refetchInterval: 3000,
  });

  const startTrainingMutation = useMutation({
    mutationFn: async (params: { rounds: number; clientsPerRound: number }) => {
      const response = await fetch("/api/federated-learning/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params),
      });
      if (!response.ok) throw new Error("Failed to start training");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Federated Training Started",
        description: "Training across the federated network has begun",
      });
      setIsTraining(true);
    },
    onError: () => {
      toast({
        title: "Training Failed",
        description: "Failed to start federated training",
        variant: "destructive",
      });
      setIsTraining(false);
    },
  });

  // Listen for training progress updates
  useEffect(() => {
    const unsubscribe = subscribe("federated_training_progress", (data: TrainingProgress) => {
      setTrainingProgress(data);
      
      if (data.round === data.totalRounds) {
        setIsTraining(false);
        toast({
          title: "Training Complete",
          description: `Federated training completed with ${(data.globalAccuracy * 100).toFixed(1)}% accuracy`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/quantum-models"] });
      }
    });

    return unsubscribe;
  }, [subscribe, toast]);

  const startFederatedTraining = () => {
    startTrainingMutation.mutate({
      rounds: 10,
      clientsPerRound: 3,
    });
  };

  const onlineNodes = nodes.filter(node => node.isOnline);
  const avgPrivacy = nodes.length > 0 
    ? nodes.reduce((sum, node) => sum + node.privacyLevel, 0) / nodes.length 
    : 0;
  const avgLatency = onlineNodes.length > 0
    ? onlineNodes.reduce((sum, node) => sum + node.latency, 0) / onlineNodes.length
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="page-title">Federated Network</h1>
            <p className="text-muted-foreground">Manage distributed learning across institutional partners</p>
          </div>
          <div className="flex space-x-3">
            <Button
              onClick={startFederatedTraining}
              disabled={isTraining || startTrainingMutation.isPending}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-start-training"
            >
              {isTraining ? (
                <>
                  <Activity className="h-4 w-4 mr-2 animate-spin" />
                  Training...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Start Training
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => refetch()} data-testid="button-refresh">
              <Network className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Network Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Users className="h-4 w-4 mr-2" />
                Active Nodes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="active-nodes-count">
                {onlineNodes.length}
              </div>
              <div className="text-sm text-muted-foreground">
                of {nodes.length} total nodes
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Shield className="h-4 w-4 mr-2" />
                Privacy Level
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="privacy-level">
                {(avgPrivacy * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Average across network
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Zap className="h-4 w-4 mr-2" />
                Avg Latency
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="avg-latency">
                {avgLatency.toFixed(0)}ms
              </div>
              <div className="text-sm text-muted-foreground">
                Network response time
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Globe className="h-4 w-4 mr-2" />
                Network Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center">
                <div className="w-2 h-2 bg-accent rounded-full mr-2 federated-pulse"></div>
                <div className="text-sm font-medium text-accent" data-testid="network-status">
                  {isTraining ? "Training" : "Ready"}
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                Federated learning
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Training Progress */}
        {isTraining && trainingProgress && (
          <Card className="mb-8 bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2 text-primary animate-pulse" />
                Federated Training Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Training Round {trainingProgress.round} of {trainingProgress.totalRounds}</span>
                    <span>{Math.round((trainingProgress.round / trainingProgress.totalRounds) * 100)}%</span>
                  </div>
                  <Progress value={(trainingProgress.round / trainingProgress.totalRounds) * 100} className="h-2" />
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {trainingProgress.participatingClients}
                    </div>
                    <div className="text-muted-foreground">Active Clients</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {(trainingProgress.globalAccuracy * 100).toFixed(1)}%
                    </div>
                    <div className="text-muted-foreground">Global Accuracy</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {trainingProgress.convergence.toFixed(3)}
                    </div>
                    <div className="text-muted-foreground">Convergence</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {trainingProgress.reconstructionError.toFixed(4)}
                    </div>
                    <div className="text-muted-foreground">Reconstruction Error</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-accent">
                      {(trainingProgress.privacyBudget * 100).toFixed(1)}%
                    </div>
                    <div className="text-muted-foreground">Privacy Preserved</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Federated Network Status */}
        <FederatedNetworkStatus />

        {/* Node Details */}
        <Card className="mt-8 bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Network className="h-5 w-5 mr-2" />
              Network Topology
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {nodes.map((node) => (
                  <Card key={node.id} className="bg-muted/20 border-border hover:bg-muted/30 transition-colors"
                        data-testid={`node-card-${node.id}`}>
                    <CardHeader className="pb-4">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg font-medium">{node.name}</CardTitle>
                        <Badge 
                          variant={node.isOnline ? "default" : "secondary"} 
                          className={node.isOnline ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}
                        >
                          {node.isOnline ? "Online" : "Offline"}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">{node.institutionType}</div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <div className="text-muted-foreground">Sync Progress</div>
                          <div className="font-semibold text-foreground">
                            {(node.modelSyncProgress * 100).toFixed(0)}%
                          </div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Latency</div>
                          <div className="font-semibold text-foreground">{node.latency}ms</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Privacy Level</div>
                          <div className="font-semibold text-accent">
                            {(node.privacyLevel * 100).toFixed(1)}%
                          </div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Last Seen</div>
                          <div className="font-semibold text-foreground text-xs">
                            {new Date(node.lastSeen).toLocaleTimeString()}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}