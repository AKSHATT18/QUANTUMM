import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import FraudAlertPanel from "@/components/FraudAlertPanel";
import TransactionMonitor from "@/components/TransactionMonitor";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Shield, TrendingUp, Eye, Activity, Brain, Zap } from "lucide-react";
import { useWebSocket } from "@/hooks/useWebSocket";

interface FraudAlert {
  id: string;
  transactionId: string;
  alertType: string;
  riskScore: number;
  quantumConfidence: number;
  description: string;
  timestamp: string;
  status: string;
}

interface FraudStats {
  totalAlerts: number;
  criticalAlerts: number;
  resolvedAlerts: number;
  averageRiskScore: number;
  quantumAccuracy: number;
  falsePositiveRate: number;
}

export default function FraudDetection() {
  const [stats, setStats] = useState<FraudStats>({
    totalAlerts: 0,
    criticalAlerts: 0,
    resolvedAlerts: 0,
    averageRiskScore: 0,
    quantumAccuracy: 0.924,
    falsePositiveRate: 0.032,
  });

  const { subscribe } = useWebSocket();

  const { data: alerts = [], isLoading: alertsLoading } = useQuery<FraudAlert[]>({
    queryKey: ["/api/fraud-alerts"],
    refetchInterval: 2000,
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 5000,
  });

  useEffect(() => {
    if (alerts.length > 0) {
      const criticalCount = alerts.filter(alert => alert.riskScore > 0.8).length;
      const resolvedCount = alerts.filter(alert => alert.status === "resolved").length;
      const avgRisk = alerts.reduce((sum, alert) => sum + alert.riskScore, 0) / alerts.length;
      
      setStats({
        totalAlerts: alerts.length,
        criticalAlerts: criticalCount,
        resolvedAlerts: resolvedCount,
        averageRiskScore: avgRisk,
        quantumAccuracy: (dashboardData as any)?.stats?.quantumAccuracy || 0.924,
        falsePositiveRate: 0.032,
      });
    }
  }, [alerts, dashboardData]);

  const getRiskLevel = (score: number) => {
    if (score >= 0.9) return { label: "Critical", color: "bg-red-500 text-red-50", icon: AlertTriangle };
    if (score >= 0.7) return { label: "High", color: "bg-orange-500 text-orange-50", icon: AlertTriangle };
    if (score >= 0.5) return { label: "Medium", color: "bg-yellow-500 text-yellow-50", icon: Eye };
    if (score >= 0.3) return { label: "Low", color: "bg-blue-500 text-blue-50", icon: Activity };
    return { label: "Minimal", color: "bg-green-500 text-green-50", icon: Shield };
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="page-title">Fraud Detection</h1>
            <p className="text-muted-foreground">Monitor and manage fraud detection with quantum-enhanced AI</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" data-testid="button-export-report">
              Export Report
            </Button>
            <Button className="bg-primary hover:bg-primary/90" data-testid="button-configure-rules">
              <Brain className="h-4 w-4 mr-2" />
              Configure Rules
            </Button>
          </div>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Total Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="total-alerts">
                {stats.totalAlerts}
              </div>
              <div className="text-sm text-muted-foreground">
                All time
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <AlertTriangle className="h-4 w-4 mr-2 text-red-500" />
                Critical
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-500" data-testid="critical-alerts">
                {stats.criticalAlerts}
              </div>
              <div className="text-sm text-muted-foreground">
                High priority
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Shield className="h-4 w-4 mr-2" />
                Resolved
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="resolved-alerts">
                {stats.resolvedAlerts}
              </div>
              <div className="text-sm text-muted-foreground">
                Completed
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <TrendingUp className="h-4 w-4 mr-2" />
                Avg Risk
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="avg-risk-score">
                {(stats.averageRiskScore * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Risk score
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Brain className="h-4 w-4 mr-2" />
                Quantum AI
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-primary" data-testid="quantum-accuracy">
                {(stats.quantumAccuracy * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Accuracy
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Zap className="h-4 w-4 mr-2" />
                False Positive
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="false-positive-rate">
                {(stats.falsePositiveRate * 100).toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Rate
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Alerts */}
          <div className="lg:col-span-1">
            <FraudAlertPanel />
          </div>

          {/* Right Column - Transactions */}
          <div className="lg:col-span-2">
            <TransactionMonitor />
          </div>
        </div>

        {/* Detailed Analysis */}
        <Card className="mt-8 bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Brain className="h-5 w-5 mr-2" />
              Risk Analysis Breakdown
            </CardTitle>
          </CardHeader>
          <CardContent>
            {alertsLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <div className="space-y-4">
                {alerts.slice(0, 10).map((alert) => {
                  const riskLevel = getRiskLevel(alert.riskScore);
                  const RiskIcon = riskLevel.icon;
                  
                  return (
                    <div key={alert.id} 
                         className="flex items-center justify-between p-4 bg-muted/20 rounded-lg hover:bg-muted/30 transition-colors"
                         data-testid={`alert-detail-${alert.id}`}>
                      <div className="flex items-center space-x-4">
                        <RiskIcon className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <div className="font-medium text-foreground">
                            Transaction {alert.transactionId.slice(0, 8)}...
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {alert.description}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {new Date(alert.timestamp).toLocaleString()}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <div className="text-right text-sm">
                          <div className="text-foreground font-medium">
                            {(alert.riskScore * 100).toFixed(1)}% Risk
                          </div>
                          <div className="text-muted-foreground">
                            {(alert.quantumConfidence * 100).toFixed(0)}% Confidence
                          </div>
                        </div>
                        <Badge className={riskLevel.color}>
                          {riskLevel.label}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
                
                {alerts.length === 0 && !alertsLoading && (
                  <div className="text-center py-12" data-testid="no-alerts">
                    <Shield className="h-12 w-12 mx-auto text-accent mb-4" />
                    <p className="text-foreground font-medium">No fraud alerts</p>
                    <p className="text-sm text-muted-foreground mt-2">Your system is running securely</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}