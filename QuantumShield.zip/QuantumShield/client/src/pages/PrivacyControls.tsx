import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { Lock, Shield, Eye, EyeOff, Key, AlertTriangle, CheckCircle, Settings as SettingsIcon } from "lucide-react";

interface PrivacySettings {
  differentialPrivacy: boolean;
  privacyBudget: number;
  homomorphicEncryption: boolean;
  secureAggregation: boolean;
  dataMinimization: boolean;
  anonymization: boolean;
  auditLogging: boolean;
  accessControl: boolean;
}

interface PrivacyMetrics {
  dataPrivacyScore: number;
  encryptionLevel: number;
  anonymizationRate: number;
  privacyBudgetUsed: number;
  complianceScore: number;
  lastAuditDate: string;
}

export default function PrivacyControls() {
  const [settings, setSettings] = useState<PrivacySettings>({
    differentialPrivacy: true,
    privacyBudget: 0.1,
    homomorphicEncryption: true,
    secureAggregation: true,
    dataMinimization: true,
    anonymization: true,
    auditLogging: true,
    accessControl: true,
  });

  const [metrics, setMetrics] = useState<PrivacyMetrics>({
    dataPrivacyScore: 96.8,
    encryptionLevel: 256,
    anonymizationRate: 94.2,
    privacyBudgetUsed: 23.5,
    complianceScore: 98.1,
    lastAuditDate: new Date().toISOString(),
  });

  const { data: federatedData } = useQuery({
    queryKey: ["/api/federated-nodes"],
    refetchInterval: 5000,
  });

  const updateSetting = (key: keyof PrivacySettings, value: boolean | number) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const complianceStandards = [
    { name: "GDPR", status: "Compliant", score: 98 },
    { name: "CCPA", status: "Compliant", score: 96 },
    { name: "HIPAA", status: "Compliant", score: 99 },
    { name: "SOC 2", status: "Compliant", score: 97 },
    { name: "ISO 27001", status: "Compliant", score: 95 },
  ];

  const privacyFeatures = [
    {
      title: "Differential Privacy",
      description: "Mathematical guarantee of privacy protection",
      enabled: settings.differentialPrivacy,
      key: "differentialPrivacy" as keyof PrivacySettings,
      icon: Shield,
      critical: true,
    },
    {
      title: "Homomorphic Encryption",
      description: "Computation on encrypted data without decryption",
      enabled: settings.homomorphicEncryption,
      key: "homomorphicEncryption" as keyof PrivacySettings,
      icon: Key,
      critical: true,
    },
    {
      title: "Secure Aggregation",
      description: "Privacy-preserving model aggregation",
      enabled: settings.secureAggregation,
      key: "secureAggregation" as keyof PrivacySettings,
      icon: Shield,
      critical: true,
    },
    {
      title: "Data Minimization",
      description: "Only collect and process necessary data",
      enabled: settings.dataMinimization,
      key: "dataMinimization" as keyof PrivacySettings,
      icon: EyeOff,
      critical: false,
    },
    {
      title: "Data Anonymization",
      description: "Remove personally identifiable information",
      enabled: settings.anonymization,
      key: "anonymization" as keyof PrivacySettings,
      icon: EyeOff,
      critical: false,
    },
    {
      title: "Audit Logging",
      description: "Track all data access and processing",
      enabled: settings.auditLogging,
      key: "auditLogging" as keyof PrivacySettings,
      icon: Eye,
      critical: false,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="page-title">Privacy Controls</h1>
            <p className="text-muted-foreground">Manage data privacy and security settings across the platform</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" data-testid="button-audit-report">
              <Eye className="h-4 w-4 mr-2" />
              Audit Report
            </Button>
            <Button className="bg-primary hover:bg-primary/90" data-testid="button-privacy-assessment">
              <Shield className="h-4 w-4 mr-2" />
              Privacy Assessment
            </Button>
          </div>
        </div>

        {/* Privacy Score Overview */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Shield className="h-4 w-4 mr-2" />
                Privacy Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="privacy-score">
                {metrics.dataPrivacyScore.toFixed(1)}
              </div>
              <div className="text-sm text-muted-foreground">
                out of 100
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Key className="h-4 w-4 mr-2" />
                Encryption
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="encryption-level">
                AES-{metrics.encryptionLevel}
              </div>
              <div className="text-sm text-muted-foreground">
                End-to-end
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <EyeOff className="h-4 w-4 mr-2" />
                Anonymization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="anonymization-rate">
                {metrics.anonymizationRate.toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Data protected
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <Lock className="h-4 w-4 mr-2" />
                Privacy Budget
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground" data-testid="privacy-budget-used">
                {metrics.privacyBudgetUsed.toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Used today
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
                <CheckCircle className="h-4 w-4 mr-2" />
                Compliance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-accent" data-testid="compliance-score">
                {metrics.complianceScore.toFixed(1)}%
              </div>
              <div className="text-sm text-muted-foreground">
                Standards met
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Privacy Configuration */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Privacy Settings */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <SettingsIcon className="h-5 w-5 mr-2" />
                Privacy Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {privacyFeatures.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div key={feature.key} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg"
                       data-testid={`privacy-feature-${feature.key}`}>
                    <div className="flex items-center space-x-4">
                      <Icon className={`h-5 w-5 ${feature.enabled ? 'text-accent' : 'text-muted-foreground'}`} />
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-foreground">{feature.title}</span>
                          {feature.critical && (
                            <Badge variant="secondary" className="bg-red-500/20 text-red-500 text-xs">
                              Critical
                            </Badge>
                          )}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {feature.description}
                        </div>
                      </div>
                    </div>
                    <Switch
                      checked={feature.enabled}
                      onCheckedChange={(checked) => updateSetting(feature.key, checked)}
                    />
                  </div>
                );
              })}
              
              {/* Privacy Budget Slider */}
              <div className="p-4 bg-muted/20 rounded-lg">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <span className="font-medium text-foreground">Privacy Budget (ε)</span>
                    <div className="text-sm text-muted-foreground">
                      Lower values provide stronger privacy
                    </div>
                  </div>
                  <Badge variant="outline">ε = {settings.privacyBudget}</Badge>
                </div>
                <Slider
                  value={[settings.privacyBudget]}
                  onValueChange={(value) => updateSetting("privacyBudget", value[0])}
                  min={0.01}
                  max={1.0}
                  step={0.01}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>High Privacy</span>
                  <span>Low Privacy</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Compliance Dashboard */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                Compliance Standards
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {complianceStandards.map((standard) => (
                <div key={standard.name} className="flex items-center justify-between p-4 bg-muted/20 rounded-lg"
                     data-testid={`compliance-${standard.name.toLowerCase()}`}>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-accent" />
                    <div>
                      <div className="font-medium text-foreground">{standard.name}</div>
                      <div className="text-sm text-muted-foreground">{standard.status}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-foreground">
                      {standard.score}%
                    </div>
                    <Progress value={standard.score} className="w-20 h-2 mt-1" />
                  </div>
                </div>
              ))}
              
              <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
                <div className="flex items-start space-x-3">
                  <Shield className="h-5 w-5 text-accent mt-0.5" />
                  <div>
                    <div className="font-medium text-accent">Privacy by Design</div>
                    <div className="text-sm text-muted-foreground mt-1">
                      All systems are designed with privacy as the default state. 
                      Personal data is protected at every stage of processing.
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Privacy Audit Log */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Eye className="h-5 w-5 mr-2" />
              Privacy Audit Trail
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  timestamp: new Date().toISOString(),
                  action: "Privacy settings updated",
                  user: "System Admin",
                  details: "Differential privacy epsilon adjusted to 0.1",
                },
                {
                  timestamp: new Date(Date.now() - 3600000).toISOString(),
                  action: "Data anonymization completed",
                  user: "Privacy Engine",
                  details: "Anonymized 2,847 transaction records",
                },
                {
                  timestamp: new Date(Date.now() - 7200000).toISOString(),
                  action: "Compliance audit initiated",
                  user: "Audit System",
                  details: "GDPR compliance verification started",
                },
                {
                  timestamp: new Date(Date.now() - 10800000).toISOString(),
                  action: "Secure aggregation enabled",
                  user: "Federated Coordinator",
                  details: "Privacy-preserving model aggregation activated",
                },
                {
                  timestamp: new Date(Date.now() - 14400000).toISOString(),
                  action: "Encryption key rotation",
                  user: "Security Service",
                  details: "AES-256 encryption keys rotated successfully",
                },
              ].map((log, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/10 rounded-lg hover:bg-muted/20 transition-colors"
                     data-testid={`audit-log-${index}`}>
                  <div className="flex items-center space-x-4">
                    <div className="w-2 h-2 bg-accent rounded-full"></div>
                    <div>
                      <div className="font-medium text-foreground">{log.action}</div>
                      <div className="text-sm text-muted-foreground">{log.details}</div>
                    </div>
                  </div>
                  <div className="text-right text-sm text-muted-foreground">
                    <div>{log.user}</div>
                    <div>{new Date(log.timestamp).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}