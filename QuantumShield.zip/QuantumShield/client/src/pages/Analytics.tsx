import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, TrendingDown, Activity, DollarSign, Shield, Zap, Calendar } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface AnalyticsData {
  transactionVolume: Array<{ time: string; count: number; amount: number }>;
  fraudTrends: Array<{ date: string; detected: number; blocked: number; falsePositives: number }>;
  riskDistribution: Array<{ name: string; value: number; color: string }>;
  performanceMetrics: {
    accuracy: number;
    precision: number;
    recall: number;
    f1Score: number;
    processingTime: number;
    throughput: number;
  };
  quantumMetrics: {
    circuitDepth: number;
    qubitUtilization: number;
    coherenceTime: number;
    gateErrors: number;
  };
}

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    transactionVolume: [],
    fraudTrends: [],
    riskDistribution: [],
    performanceMetrics: {
      accuracy: 0.924,
      precision: 0.92,
      recall: 0.89,
      f1Score: 0.88,
      processingTime: 12.5,
      throughput: 1240,
    },
    quantumMetrics: {
      circuitDepth: 8,
      qubitUtilization: 0.78,
      coherenceTime: 150.2,
      gateErrors: 0.003,
    },
  });

  const { data: dashboardData } = useQuery({
    queryKey: ["/api/dashboard"],
    refetchInterval: 10000,
  });

  useEffect(() => {
    // Generate synthetic analytics data
    const generateTimeSeriesData = () => {
      const days = timeRange === "24h" ? 1 : timeRange === "7d" ? 7 : 30;
      const points = days * (timeRange === "24h" ? 24 : 1);
      
      const transactionVolume: Array<{ time: string; count: number; amount: number }> = [];
      const fraudTrends: Array<{ date: string; detected: number; blocked: number; falsePositives: number }> = [];
      
      for (let i = 0; i < points; i++) {
        const date = new Date();
        date.setHours(date.getHours() - (points - i));
        
        const baseCount = 100 + Math.random() * 200;
        const baseAmount = baseCount * (500 + Math.random() * 1000);
        
        transactionVolume.push({
          time: timeRange === "24h" ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : date.toLocaleDateString(),
          count: Math.floor(baseCount + Math.sin(i / 5) * 50),
          amount: Math.floor(baseAmount + Math.sin(i / 3) * 10000),
        });
        
        fraudTrends.push({
          date: timeRange === "24h" ? date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : date.toLocaleDateString(),
          detected: Math.floor(Math.random() * 15 + 5),
          blocked: Math.floor(Math.random() * 12 + 3),
          falsePositives: Math.floor(Math.random() * 3 + 1),
        });
      }
      
      const riskDistribution = [
        { name: "Low Risk", value: 65, color: "#10B981" },
        { name: "Medium Risk", value: 20, color: "#F59E0B" },
        { name: "High Risk", value: 12, color: "#F97316" },
        { name: "Critical Risk", value: 3, color: "#EF4444" },
      ];
      
      setAnalyticsData(prev => ({
        ...prev,
        transactionVolume,
        fraudTrends,
        riskDistribution,
      }));
    };
    
    generateTimeSeriesData();
  }, [timeRange]);

  const MetricCard = ({ title, value, change, icon: Icon, format = "number" }: any) => {
    const isPositive = change >= 0;
    const TrendIcon = isPositive ? TrendingUp : TrendingDown;
    
    return (
      <Card className="bg-card border-border">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-muted-foreground flex items-center">
            <Icon className="h-4 w-4 mr-2" />
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">
            {format === "percent" ? `${(value * 100).toFixed(1)}%` : 
             format === "currency" ? `$${value.toLocaleString()}` :
             format === "time" ? `${value}ms` : value.toLocaleString()}
          </div>
          <div className={`flex items-center text-sm ${isPositive ? "text-accent" : "text-red-500"}`}>
            <TrendIcon className="h-3 w-3 mr-1" />
            {Math.abs(change).toFixed(1)}% vs last period
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="page-title">Analytics</h1>
            <p className="text-muted-foreground">Deep insights into fraud detection and quantum model performance</p>
          </div>
          <div className="flex space-x-3">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24h</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" data-testid="button-export">
              <Calendar className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Model Accuracy"
            value={analyticsData.performanceMetrics.accuracy}
            change={2.3}
            icon={Shield}
            format="percent"
          />
          <MetricCard
            title="Processing Speed"
            value={analyticsData.performanceMetrics.processingTime}
            change={-8.5}
            icon={Zap}
            format="time"
          />
          <MetricCard
            title="Throughput"
            value={analyticsData.performanceMetrics.throughput}
            change={12.1}
            icon={Activity}
          />
          <MetricCard
            title="F1 Score"
            value={analyticsData.performanceMetrics.f1Score}
            change={1.8}
            icon={TrendingUp}
            format="percent"
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Transaction Volume */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Transaction Volume
              </CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analyticsData.transactionVolume}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="time" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))", 
                      border: "1px solid hsl(var(--border))",
                      color: "hsl(var(--foreground))"
                    }} 
                  />
                  <Bar dataKey="count" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Fraud Detection Trends */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Fraud Detection Trends
              </CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={analyticsData.fraudTrends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: "hsl(var(--card))", 
                      border: "1px solid hsl(var(--border))",
                      color: "hsl(var(--foreground))"
                    }} 
                  />
                  <Line type="monotone" dataKey="detected" stroke="hsl(var(--primary))" strokeWidth={2} />
                  <Line type="monotone" dataKey="blocked" stroke="hsl(var(--accent))" strokeWidth={2} />
                  <Line type="monotone" dataKey="falsePositives" stroke="hsl(var(--destructive))" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Risk Distribution and Quantum Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Risk Distribution */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Risk Score Distribution
              </CardTitle>
            </CardHeader>
            <CardContent className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={analyticsData.riskDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {analyticsData.riskDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Quantum Metrics */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="h-5 w-5 mr-2" />
                Quantum System Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {analyticsData.quantumMetrics.circuitDepth}
                    </div>
                    <div className="text-sm text-muted-foreground">Circuit Depth</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent">
                      {(analyticsData.quantumMetrics.qubitUtilization * 100).toFixed(0)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Qubit Utilization</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-foreground">
                      {analyticsData.quantumMetrics.coherenceTime}μs
                    </div>
                    <div className="text-sm text-muted-foreground">Coherence Time</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-accent">
                      {(analyticsData.quantumMetrics.gateErrors * 100).toFixed(3)}%
                    </div>
                    <div className="text-sm text-muted-foreground">Gate Error Rate</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Performance Summary */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Activity className="h-5 w-5 mr-2" />
              Model Performance Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="text-center p-4 bg-muted/20 rounded-lg">
                <div className="text-xl font-semibold text-foreground">
                  {(analyticsData.performanceMetrics.accuracy * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Accuracy</div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-accent/20 text-accent">Excellent</Badge>
                </div>
              </div>
              
              <div className="text-center p-4 bg-muted/20 rounded-lg">
                <div className="text-xl font-semibold text-foreground">
                  {(analyticsData.performanceMetrics.precision * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Precision</div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-primary/20 text-primary">High</Badge>
                </div>
              </div>
              
              <div className="text-center p-4 bg-muted/20 rounded-lg">
                <div className="text-xl font-semibold text-foreground">
                  {(analyticsData.performanceMetrics.recall * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Recall</div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-primary/20 text-primary">Good</Badge>
                </div>
              </div>
              
              <div className="text-center p-4 bg-muted/20 rounded-lg">
                <div className="text-xl font-semibold text-foreground">
                  {(analyticsData.performanceMetrics.f1Score * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">F1 Score</div>
                <div className="mt-2">
                  <Badge variant="secondary" className="bg-accent/20 text-accent">Strong</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}