import { useEffect, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/Sidebar";
import QuantumCircuitVisualizer from "@/components/QuantumCircuitVisualizer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Atom, Play, Pause, RotateCcw, Zap, Brain, TrendingUp, Activity } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useWebSocket } from "@/hooks/useWebSocket";

interface QuantumModel {
  id: string;
  name: string;
  architecture: any;
  parameters: number[];
  trainingEpochs: number;
  reconstructionError: number | null;
  accuracy: number | null;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface TrainingProgress {
  epoch: number;
  totalEpochs: number;
  progress: number;
  reconstructionError: number;
  accuracy: number;
  isComplete: boolean;
}

export default function QuantumModels() {
  const [trainingProgress, setTrainingProgress] = useState<TrainingProgress | null>(null);
  const [isTraining, setIsTraining] = useState(false);
  const { toast } = useToast();
  const { subscribe } = useWebSocket();

  const { data: models = [], isLoading, refetch } = useQuery<QuantumModel[]>({
    queryKey: ["/api/quantum-models"],
    refetchInterval: 5000,
  });

  const { data: activeModel } = useQuery<QuantumModel>({
    queryKey: ["/api/quantum-models/active"],
    refetchInterval: 3000,
  });

  const trainModelMutation = useMutation({
    mutationFn: async (epochs: number = 50) => {
      const response = await fetch("/api/quantum-models/train", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ epochs }),
      });
      if (!response.ok) throw new Error("Training failed");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Training Started",
        description: `Training quantum model for ${data.epochs} epochs`,
      });
    },
    onError: () => {
      toast({
        title: "Training Failed",
        description: "Failed to start quantum model training",
        variant: "destructive",
      });
      setIsTraining(false);
      setTrainingProgress(null);
    },
  });

  // Listen for training progress updates
  useEffect(() => {
    const unsubscribeProgress = subscribe("training_progress", (data: TrainingProgress) => {
      setTrainingProgress(data);
      
      if (data.isComplete) {
        setIsTraining(false);
        toast({
          title: "Training Complete",
          description: `Model achieved ${(data.accuracy * 100).toFixed(1)}% accuracy`,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/quantum-models"] });
        queryClient.invalidateQueries({ queryKey: ["/api/quantum-models/active"] });
      }
    });

    const unsubscribeComplete = subscribe("training_complete", (data: any) => {
      setIsTraining(false);
      setTrainingProgress(null);
      toast({
        title: "Training Complete",
        description: `Model trained with ${data.finalAccuracy.toFixed(3)} accuracy in ${(data.trainingTime / 1000).toFixed(1)}s`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/quantum-models"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quantum-models/active"] });
    });

    return () => {
      unsubscribeProgress();
      unsubscribeComplete();
    };
  }, [subscribe, toast]);

  const startTraining = () => {
    setIsTraining(true);
    setTrainingProgress(null);
    trainModelMutation.mutate(50);
  };

  const getModelStatus = (model: QuantumModel) => {
    if (model.isActive) return { label: "Active", color: "bg-accent", textColor: "text-accent" };
    if (model.accuracy && model.accuracy > 0.9) return { label: "Trained", color: "bg-primary", textColor: "text-primary" };
    if (model.trainingEpochs > 0) return { label: "Partially Trained", color: "bg-chart-3", textColor: "text-chart-3" };
    return { label: "Untrained", color: "bg-muted", textColor: "text-muted-foreground" };
  };

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      
      <main className="ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="page-title">Quantum Models</h1>
            <p className="text-muted-foreground">Manage and monitor quantum machine learning models</p>
          </div>
          <div className="flex space-x-3">
            <Button
              onClick={startTraining}
              disabled={isTraining}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-train-model"
            >
              {isTraining ? (
                <>
                  <Activity className="h-4 w-4 mr-2 animate-spin" />
                  Training...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Train Model
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => refetch()} data-testid="button-refresh">
              <RotateCcw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Active Model Performance */}
        {activeModel && (
          <div className="mb-8">
            <QuantumCircuitVisualizer
              reconstructionError={activeModel.reconstructionError || 0.0847}
              trainingEpochs={activeModel.trainingEpochs}
              maxEpochs={500}
              parameters={activeModel.parameters}
              isTraining={isTraining}
            />
          </div>
        )}

        {/* Training Progress */}
        {isTraining && trainingProgress && (
          <Card className="mb-8 bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="h-5 w-5 mr-2 text-primary animate-pulse" />
                Training Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Training Quantum Autoencoder</span>
                    <span>{Math.round(trainingProgress.progress)}%</span>
                  </div>
                  <Progress value={trainingProgress.progress} className="h-2" />
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {trainingProgress.epoch} / {trainingProgress.totalEpochs}
                    </div>
                    <div className="text-muted-foreground">Epochs</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {trainingProgress.reconstructionError.toFixed(4)}
                    </div>
                    <div className="text-muted-foreground">Reconstruction Error</div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold text-foreground">
                      {(trainingProgress.accuracy * 100).toFixed(1)}%
                    </div>
                    <div className="text-muted-foreground">Accuracy</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Training Status when no progress yet */}
        {isTraining && !trainingProgress && (
          <Card className="mb-8 bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="h-5 w-5 mr-2 text-primary animate-spin" />
                Initializing Training...
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center py-4">
                <div className="text-muted-foreground">Setting up quantum model training pipeline...</div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Model Gallery */}
        <div className="grid gap-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Atom className="h-5 w-5 mr-2" />
                Quantum Model Registry
              </CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : models.length === 0 ? (
                <div className="text-center py-12" data-testid="no-models">
                  <Atom className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No quantum models found</p>
                  <p className="text-sm text-muted-foreground mt-2">Train your first model to get started</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {models.map((model) => {
                    const status = getModelStatus(model);
                    return (
                      <Card key={model.id} className="bg-muted/20 border-border hover:bg-muted/30 transition-colors"
                            data-testid={`model-card-${model.id}`}>
                        <CardHeader className="pb-4">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-lg font-medium">{model.name}</CardTitle>
                            <Badge variant="secondary" className={`${status.color} ${status.textColor}`}>
                              {status.label}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <div className="text-muted-foreground">Epochs</div>
                              <div className="font-semibold text-foreground">{model.trainingEpochs}</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Accuracy</div>
                              <div className="font-semibold text-foreground">
                                {model.accuracy ? `${(model.accuracy * 100).toFixed(1)}%` : "N/A"}
                              </div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Parameters</div>
                              <div className="font-semibold text-foreground">{model.parameters?.length || 0}</div>
                            </div>
                            <div>
                              <div className="text-muted-foreground">Error</div>
                              <div className="font-semibold text-foreground">
                                {model.reconstructionError ? model.reconstructionError.toFixed(4) : "N/A"}
                              </div>
                            </div>
                          </div>
                          
                          {model.isActive && (
                            <div className="flex items-center text-accent text-sm">
                              <Zap className="h-3 w-3 mr-1" />
                              Currently Active
                            </div>
                          )}
                          
                          <div className="text-xs text-muted-foreground">
                            Updated: {new Date(model.updatedAt).toLocaleDateString()}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}