import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/Sidebar";
import QuantumCircuitVisualizer from "@/components/QuantumCircuitVisualizer";
import FederatedNetworkStatus from "@/components/FederatedNetworkStatus";
import FraudAlertPanel from "@/components/FraudAlertPanel";
import TransactionMonitor from "@/components/TransactionMonitor";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Bell, User, Globe, AlertTriangle, Atom, Network, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DashboardStats {
  fraudCount: number;
  quantumAccuracy: number;
  federatedNodes: string;
  transactionRate: number;
}

interface DashboardData {
  stats: DashboardStats;
  quantumModel: {
    reconstructionError: number;
    trainingEpochs: number;
    accuracy: number;
  } | null;
  federatedNodes: Array<{
    id: string;
    name: string;
    syncProgress: number;
    latency: number;
    privacyLevel: number;
  }>;
  fraudAlerts: any[];
  recentTransactions: any[];
}

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    fraudCount: 0,
    quantumAccuracy: 0,
    federatedNodes: "0/0",
    transactionRate: 0
  });

  const { toast } = useToast();
  const { subscribe, isConnected } = useWebSocket();

  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard"],
    refetchInterval: 10000, // Refresh every 10 seconds
  });

  useEffect(() => {
    if (data) {
      setStats(data.stats);
    }
  }, [data]);

  // Subscribe to real-time fraud alerts
  useEffect(() => {
    const unsubscribeFraudAlert = subscribe("fraud_alert", (alertData) => {
      toast({
        title: "🚨 Fraud Alert",
        description: `${alertData.severity === "critical" ? "Critical" : "High"} risk transaction detected`,
        variant: alertData.severity === "critical" ? "destructive" : "default",
      });
      
      // Update fraud count
      setStats(prev => ({
        ...prev,
        fraudCount: prev.fraudCount + 1
      }));
    });

    const unsubscribeModelUpdate = subscribe("model_update", (modelData) => {
      toast({
        title: "🔬 Quantum Model Updated",
        description: `Model convergence: ${(modelData.convergence * 100).toFixed(1)}%`,
      });
    });

    const unsubscribeFederatedSync = subscribe("federated_sync", (syncData) => {
      if (syncData.nodeId === "global") {
        toast({
          title: "🌐 Federated Training Complete",
          description: `Global model synchronization: ${(syncData.syncProgress * 100).toFixed(1)}%`,
        });
      }
    });

    return () => {
      unsubscribeFraudAlert();
      unsubscribeModelUpdate();
      unsubscribeFederatedSync();
    };
  }, [subscribe, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background neural-network-bg">
        <Sidebar />
        <main className="ml-64">
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center">
              <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading quantum fraud detection system...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background neural-network-bg">
        <Sidebar />
        <main className="ml-64">
          <div className="flex items-center justify-center min-h-screen">
            <div className="text-center">
              <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
              <p className="text-destructive mb-2">Failed to load dashboard</p>
              <p className="text-muted-foreground text-sm">Please check your connection and try again</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background neural-network-bg" data-testid="dashboard">
      <Sidebar />
      
      <main className="ml-64">
        {/* Header */}
        <header className="bg-card border-b border-border px-6 py-4" data-testid="dashboard-header">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Fraud Detection Command Center</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Real-time quantum-enhanced fraud monitoring across federated banking network
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-muted/30 px-3 py-2 rounded-lg">
                <Globe className="h-4 w-4 text-primary" />
                <span className="text-sm font-medium">Global Network</span>
                <Badge className="bg-accent text-accent-foreground text-xs">
                  {stats.federatedNodes.split('/')[0]} Banks
                </Badge>
              </div>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Button
                    size="sm"
                    variant="ghost"
                    className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-lg transition-colors"
                    data-testid="button-notifications"
                  >
                    <Bell className="h-4 w-4" />
                    {stats.fraudCount > 0 && (
                      <span className="absolute -top-1 -right-1 h-3 w-3 bg-destructive rounded-full text-xs flex items-center justify-center text-destructive-foreground">
                        {stats.fraudCount > 9 ? '9+' : stats.fraudCount}
                      </span>
                    )}
                  </Button>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="p-2 text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-lg transition-colors"
                  data-testid="button-user"
                >
                  <User className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Connection Status */}
          <div className="mt-4 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-accent' : 'bg-destructive'} ${isConnected ? 'federated-pulse' : ''}`} />
                <span className={`text-xs ${isConnected ? 'text-accent' : 'text-destructive'}`}>
                  WebSocket {isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              <span className="text-muted-foreground">
                Last Updated: {new Date().toLocaleTimeString()}
              </span>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="p-6 space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid="stats-overview">
            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Fraud Detected Today</p>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-2xl font-bold text-destructive" data-testid="fraud-count">
                        {stats.fraudCount}
                      </p>
                      <Badge variant="secondary" className="bg-destructive/10 text-destructive text-xs">
                        +12%
                      </Badge>
                    </div>
                  </div>
                  <div className="p-3 bg-destructive/10 rounded-lg">
                    <AlertTriangle className="h-5 w-5 text-destructive" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Quantum Accuracy</p>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-2xl font-bold text-accent" data-testid="quantum-accuracy">
                        {(stats.quantumAccuracy * 100).toFixed(1)}%
                      </p>
                      <Badge variant="secondary" className="bg-accent/10 text-accent text-xs">
                        +2.1%
                      </Badge>
                    </div>
                  </div>
                  <div className="p-3 bg-accent/10 rounded-lg">
                    <Atom className="h-5 w-5 text-accent" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Federated Nodes</p>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-2xl font-bold text-primary" data-testid="federated-nodes">
                        {stats.federatedNodes}
                      </p>
                      <Badge variant="secondary" className="bg-primary/10 text-primary text-xs">
                        Online
                      </Badge>
                    </div>
                  </div>
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <Network className="h-5 w-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Transactions/sec</p>
                    <div className="flex items-baseline space-x-2">
                      <p className="text-2xl font-bold text-chart-3" data-testid="transaction-rate">
                        {stats.transactionRate.toLocaleString()}
                      </p>
                      <Badge variant="secondary" className="bg-chart-3/10 text-chart-3 text-xs">
                        Real-time
                      </Badge>
                    </div>
                  </div>
                  <div className="p-3 bg-chart-3/10 rounded-lg">
                    <Zap className="h-5 w-5 text-chart-3" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Main Dashboard Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Quantum Model Status */}
            <div className="lg:col-span-2">
              <QuantumCircuitVisualizer
                reconstructionError={data?.quantumModel?.reconstructionError}
                trainingEpochs={data?.quantumModel?.trainingEpochs}
                maxEpochs={500}
                parameters={data?.quantumModel ? [0.5, 0.8, 1.2, 0.3] : []}
                isTraining={false}
              />
            </div>

            {/* Federated Network Status */}
            <div className="lg:col-span-1">
              <FederatedNetworkStatus />
            </div>
          </div>

          {/* Fraud Detection Panel */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <FraudAlertPanel />

            <Card className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-foreground">Model Performance Metrics</h3>
                  <Button variant="link" className="text-primary hover:text-primary/80 text-sm font-medium p-0">
                    View Details
                  </Button>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-muted-foreground">Detection Accuracy</span>
                      <span className="text-sm font-bold text-foreground" data-testid="detection-accuracy">
                        {data?.quantumModel?.accuracy ? (data.quantumModel.accuracy * 100).toFixed(1) : '92.4'}%
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-accent h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${data?.quantumModel?.accuracy ? data.quantumModel.accuracy * 100 : 92.4}%` }}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-muted-foreground">False Positive Rate</span>
                      <span className="text-sm font-bold text-foreground" data-testid="false-positive-rate">3.2%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-chart-3 h-2 rounded-full" style={{ width: '3.2%' }} />
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-muted-foreground">Model Convergence</span>
                      <span className="text-sm font-bold text-foreground" data-testid="model-convergence">87.6%</span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div className="bg-primary h-2 rounded-full" style={{ width: '87.6%' }} />
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-border">
                    <div className="grid grid-cols-2 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-foreground" data-testid="f1-score">0.88</div>
                        <div className="text-xs text-muted-foreground">F1 Score</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-foreground" data-testid="precision">0.92</div>
                        <div className="text-xs text-muted-foreground">Precision</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Transaction Monitoring */}
          <TransactionMonitor />
        </div>
      </main>
    </div>
  );
}
