import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Globe, Wifi, Shield, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface FederatedNode {
  id: string;
  name: string;
  institutionType: string;
  isOnline: boolean;
  modelSyncProgress: number;
  latency: number;
  privacyLevel: number;
  lastSeen: string;
}

export default function FederatedNetworkStatus() {
  const [animatedNodes, setAnimatedNodes] = useState<Set<string>>(new Set());

  const { data: nodes, isLoading } = useQuery<FederatedNode[]>({
    queryKey: ["/api/federated-nodes"],
    refetchInterval: 5000,
  });

  const nodeList = nodes || [];

  useEffect(() => {
    if (!nodeList.length) return;
    
    // Animate nodes with recent updates
    const recentlyUpdated = nodeList.filter((node) => {
      const lastSeen = new Date(node.lastSeen);
      const now = new Date();
      return now.getTime() - lastSeen.getTime() < 10000; // Within last 10 seconds
    });

    const newAnimatedNodes = new Set(recentlyUpdated.map((node) => node.id));
    
    // Only update if there's actually a change
    setAnimatedNodes(prev => {
      const prevIds = Array.from(prev).sort().join(',');
      const newIds = Array.from(newAnimatedNodes).sort().join(',');
      return prevIds !== newIds ? newAnimatedNodes : prev;
    });

    // Clear animation after a delay
    const timeout = setTimeout(() => {
      setAnimatedNodes(new Set());
    }, 2000);

    return () => clearTimeout(timeout);
  }, [nodeList.length, nodeList.map(n => `${n.id}-${n.lastSeen}`).join(',')]);

  const onlineNodes = nodeList.filter((node) => node.isOnline);
  const avgPrivacy = nodeList.length > 0 
    ? nodeList.reduce((sum, node) => sum + node.privacyLevel, 0) / nodeList.length 
    : 0;

  const getLatencyColor = (latency: number) => {
    if (latency < 25) return "text-accent";
    if (latency < 50) return "text-primary";
    if (latency < 100) return "text-chart-3";
    return "text-destructive";
  };

  const getSyncColor = (progress: number) => {
    if (progress >= 0.95) return "text-accent";
    if (progress >= 0.90) return "text-primary";
    if (progress >= 0.80) return "text-chart-3";
    return "text-destructive";
  };

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Federated Network</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="federated-network-status">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Globe className="h-5 w-5 mr-2" />
            Federated Network
          </span>
          <Badge variant="secondary" className="bg-accent/10 text-accent" data-testid="active-nodes-badge">
            {onlineNodes.length} Active Nodes
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-4" data-testid="federated-nodes-list">
          {nodeList.slice(0, 6).map((node) => (
            <div 
              key={node.id} 
              className={`flex items-center justify-between p-3 bg-muted/20 rounded-lg transition-all duration-300 ${
                animatedNodes.has(node.id) ? 'ring-2 ring-primary' : ''
              }`}
              data-testid={`federated-node-${node.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <div className={`w-3 h-3 rounded-full ${
                    node.isOnline 
                      ? node.modelSyncProgress > 0.95 
                        ? 'bg-accent' 
                        : 'bg-primary' 
                      : 'bg-muted-foreground'
                  } ${node.isOnline ? 'federated-pulse' : ''}`} 
                  data-testid={`node-status-${node.id}`} />
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground" data-testid={`node-name-${node.id}`}>
                    {node.name}
                  </div>
                  <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                    <span data-testid={`node-type-${node.id}`}>{node.institutionType}</span>
                    <span>•</span>
                    <span className={getSyncColor(node.modelSyncProgress)} data-testid={`node-sync-${node.id}`}>
                      Model sync: {(node.modelSyncProgress * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                {node.isOnline && (
                  <>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Wifi className="h-3 w-3 mr-1" />
                      <span className={getLatencyColor(node.latency)} data-testid={`node-latency-${node.id}`}>
                        {node.latency}ms
                      </span>
                    </div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Clock className="h-3 w-3 mr-1" />
                      <span data-testid={`node-last-seen-${node.id}`}>
                        {new Date(node.lastSeen).toLocaleTimeString()}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="pt-4 border-t border-border">
          <div className="flex items-center justify-between text-sm mb-2">
            <span className="flex items-center text-muted-foreground">
              <Shield className="h-4 w-4 mr-2" />
              Privacy Preservation
            </span>
            <span className="text-accent font-semibold" data-testid="privacy-percentage">
              {(avgPrivacy * 100).toFixed(1)}%
            </span>
          </div>
          <div className="w-full bg-muted mt-2 rounded-full h-2">
            <div 
              className="bg-accent h-2 rounded-full transition-all duration-500" 
              style={{ width: `${avgPrivacy * 100}%` }}
              data-testid="privacy-progress-bar"
            />
          </div>
          <div className="text-xs text-muted-foreground mt-1" data-testid="privacy-details">
            Differential Privacy: ε=0.1 • Secure Aggregation: Active
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
