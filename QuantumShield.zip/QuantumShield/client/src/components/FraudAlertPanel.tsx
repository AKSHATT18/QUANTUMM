import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Eye, DollarSign, Clock, X } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";

interface FraudAlert {
  id: string;
  transactionId: string;
  alertType: string;
  riskScore: number;
  quantumConfidence: number;
  description: string;
  isActive: boolean;
  createdAt: string;
}

export default function FraudAlertPanel() {
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading } = useQuery<FraudAlert[]>({
    queryKey: ["/api/fraud-alerts"],
    refetchInterval: 3000,
  });

  const deactivateAlertMutation = useMutation({
    mutationFn: async (alertId: string) => {
      return await apiRequest("PATCH", `/api/fraud-alerts/${alertId}/deactivate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/fraud-alerts"] });
    },
  });

  const getAlertIcon = (alertType: string) => {
    switch (alertType) {
      case "high_value_risk":
        return DollarSign;
      case "suspicious_velocity":
        return Clock;
      case "critical_risk":
        return AlertTriangle;
      default:
        return Eye;
    }
  };

  const getAlertColor = (riskScore: number) => {
    if (riskScore >= 0.9) return "destructive";
    if (riskScore >= 0.7) return "chart-3";
    if (riskScore >= 0.5) return "primary";
    return "accent";
  };

  const getSeverityLabel = (riskScore: number) => {
    if (riskScore >= 0.9) return "Critical";
    if (riskScore >= 0.7) return "High";
    if (riskScore >= 0.5) return "Medium";
    return "Low";
  };

  const activeAlerts = alerts.filter((alert) => alert.isActive);

  if (isLoading) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Real-time Fraud Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="fraud-alert-panel">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            Real-time Fraud Alerts
          </span>
          <Badge 
            variant="secondary" 
            className={`${activeAlerts.length > 0 ? 'bg-destructive/10 text-destructive' : 'bg-accent/10 text-accent'}`}
            data-testid="active-alerts-badge"
          >
            {activeAlerts.length} Active
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {activeAlerts.length === 0 ? (
          <div className="text-center py-8" data-testid="no-alerts">
            <AlertTriangle className="h-12 w-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No active fraud alerts</p>
          </div>
        ) : (
          <div className="space-y-4" data-testid="fraud-alerts-list">
            {activeAlerts.slice(0, 5).map((alert) => {
              const AlertIcon = getAlertIcon(alert.alertType);
              const severity = getSeverityLabel(alert.riskScore);
              const alertColor = getAlertColor(alert.riskScore);
              
              return (
                <div 
                  key={alert.id} 
                  className={`flex items-start space-x-4 p-4 border rounded-lg transition-all hover:bg-muted/10 ${
                    alertColor === "destructive" 
                      ? "bg-destructive/5 border-destructive/20" 
                      : alertColor === "chart-3"
                      ? "bg-chart-3/5 border-chart-3/20"
                      : "bg-primary/5 border-primary/20"
                  }`}
                  data-testid={`fraud-alert-${alert.id}`}
                >
                  <div className={`p-2 rounded-lg ${
                    alertColor === "destructive" 
                      ? "bg-destructive/10" 
                      : alertColor === "chart-3"
                      ? "bg-chart-3/10"
                      : "bg-primary/10"
                  }`}>
                    <AlertIcon className={`h-4 w-4 ${
                      alertColor === "destructive" 
                        ? "text-destructive" 
                        : alertColor === "chart-3"
                        ? "text-chart-3"
                        : "text-primary"
                    }`} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-semibold text-foreground" data-testid={`alert-title-${alert.id}`}>
                        {alert.alertType.split('_').map(word => 
                          word.charAt(0).toUpperCase() + word.slice(1)
                        ).join(' ')}
                      </span>
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${
                            alertColor === "destructive" 
                              ? "border-destructive text-destructive" 
                              : alertColor === "chart-3"
                              ? "border-chart-3 text-chart-3"
                              : "border-primary text-primary"
                          }`}
                          data-testid={`alert-severity-${alert.id}`}
                        >
                          {severity}
                        </Badge>
                        <span className="text-xs text-muted-foreground font-mono" data-testid={`alert-time-${alert.id}`}>
                          {formatDistanceToNow(new Date(alert.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-sm text-muted-foreground mb-2" data-testid={`alert-description-${alert.id}`}>
                      {alert.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-xs">
                        <span className={`${
                          alertColor === "destructive" 
                            ? "text-destructive" 
                            : alertColor === "chart-3"
                            ? "text-chart-3"
                            : "text-primary"
                        }`} data-testid={`alert-risk-score-${alert.id}`}>
                          Risk Score: {alert.riskScore.toFixed(2)}
                        </span>
                        <span className="text-accent" data-testid={`alert-quantum-confidence-${alert.id}`}>
                          Quantum Confidence: {(alert.quantumConfidence * 100).toFixed(0)}%
                        </span>
                      </div>
                      
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deactivateAlertMutation.mutate(alert.id)}
                        disabled={deactivateAlertMutation.isPending}
                        className="h-6 w-6 p-0 hover:bg-destructive/10"
                        data-testid={`button-dismiss-alert-${alert.id}`}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
