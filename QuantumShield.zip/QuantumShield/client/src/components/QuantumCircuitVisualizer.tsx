import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { QuantumMathUtils, type QuantumStateVisualization } from "@/lib/quantumMath";
import { Atom, RotateCcw, Gauge } from "lucide-react";

interface QuantumCircuitVisualizerProps {
  reconstructionError?: number;
  trainingEpochs?: number;
  maxEpochs?: number;
  parameters?: number[];
  isTraining?: boolean;
}

export default function QuantumCircuitVisualizer({
  reconstructionError = 0.0847,
  trainingEpochs = 247,
  maxEpochs = 500,
  parameters = [],
  isTraining = false
}: QuantumCircuitVisualizerProps) {
  const [quantumState, setQuantumState] = useState<QuantumStateVisualization | null>(null);
  const [animationFrame, setAnimationFrame] = useState(0);

  useEffect(() => {
    // Generate quantum state visualization
    const state = QuantumMathUtils.generateQuantumStateVisualization(3, parameters);
    setQuantumState(state);
  }, [parameters]);

  useEffect(() => {
    if (!isTraining) return;

    const interval = setInterval(() => {
      setAnimationFrame(prev => (prev + 1) % 360);
    }, 100);

    return () => clearInterval(interval);
  }, [isTraining]);

  const progress = maxEpochs > 0 ? (trainingEpochs / maxEpochs) * 100 : 0;

  const gates = [
    { type: 'H', target: 0, label: 'H' },
    { type: 'RY', target: 0, label: 'R', parameter: parameters[0] || 0 },
    { type: 'H', target: 1, label: 'H' },
    { type: 'RY', target: 1, label: 'R', parameter: parameters[1] || 0 },
    { type: 'M', target: 0, label: 'M' },
    { type: 'M', target: 1, label: 'M' },
  ];

  return (
    <Card className="bg-card border-border" data-testid="quantum-circuit-visualizer">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-lg font-semibold text-foreground">Quantum Autoencoder Performance</span>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-muted-foreground">Last updated:</span>
            <span className="text-xs text-foreground font-mono" data-testid="last-updated">
              {new Date().toLocaleString()}
            </span>
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-muted/30 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-muted-foreground">Reconstruction Error</span>
              <Gauge className="h-4 w-4 text-primary" />
            </div>
            <div className="text-xl font-bold text-foreground" data-testid="reconstruction-error">
              {reconstructionError.toFixed(4)}
            </div>
            <div className="text-xs text-accent">Threshold: 0.1200</div>
          </div>
          
          <div className="bg-muted/30 p-4 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-muted-foreground">Training Epochs</span>
              <RotateCcw className={cn(
                "h-4 w-4 text-accent",
                isTraining && "animate-spin"
              )} />
            </div>
            <div className="text-xl font-bold text-foreground" data-testid="training-epochs">
              {trainingEpochs}/{maxEpochs}
            </div>
            <div className="text-xs text-primary">{progress.toFixed(1)}% Complete</div>
          </div>
        </div>
        
        {/* Quantum Circuit Visualization */}
        <div className="bg-muted/20 p-4 rounded-lg">
          <h4 className="text-sm font-semibold text-foreground mb-3 flex items-center">
            <Atom className="h-4 w-4 mr-2" />
            Quantum Circuit Architecture
          </h4>
          <div className="relative" data-testid="quantum-circuit">
            <div className="grid grid-cols-8 gap-2 items-center">
              {/* First qubit line */}
              <div className="text-xs text-muted-foreground text-center">|q0⟩</div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div 
                className="w-6 h-6 bg-accent rounded-full flex items-center justify-center text-xs text-accent-foreground transition-transform"
                style={{ 
                  transform: isTraining ? `rotate(${animationFrame}deg)` : 'none'
                }}
                data-testid="gate-h-0"
              >
                H
              </div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div 
                className="w-6 h-6 bg-chart-3 rounded-full flex items-center justify-center text-xs transition-all"
                style={{
                  transform: isTraining ? `scale(${1 + 0.1 * Math.sin(animationFrame * 0.1)})` : 'scale(1)'
                }}
                data-testid="gate-ry-0"
              >
                R
              </div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div className="w-6 h-6 bg-destructive rounded-full flex items-center justify-center text-xs text-destructive-foreground" data-testid="gate-m-0">
                M
              </div>
              <div className="text-xs text-muted-foreground text-center">Classical</div>
              
              {/* Second qubit line */}
              <div className="text-xs text-muted-foreground text-center">|q1⟩</div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div 
                className="w-6 h-6 bg-accent rounded-full flex items-center justify-center text-xs text-accent-foreground transition-transform"
                style={{ 
                  transform: isTraining ? `rotate(${-animationFrame}deg)` : 'none'
                }}
                data-testid="gate-h-1"
              >
                H
              </div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div 
                className="w-6 h-6 bg-chart-3 rounded-full flex items-center justify-center text-xs transition-all"
                style={{
                  transform: isTraining ? `scale(${1 + 0.1 * Math.cos(animationFrame * 0.1)})` : 'scale(1)'
                }}
                data-testid="gate-ry-1"
              >
                R
              </div>
              <div className="h-0.5 bg-primary rounded-full"></div>
              <div className="w-6 h-6 bg-destructive rounded-full flex items-center justify-center text-xs text-destructive-foreground" data-testid="gate-m-1">
                M
              </div>
              <div className="text-xs text-muted-foreground text-center">Output</div>
            </div>
            
            {/* Legend */}
            <div className="mt-4 flex justify-center space-x-4 text-xs text-muted-foreground">
              <span className="flex items-center">
                <span className="w-2 h-2 bg-accent rounded-full inline-block mr-1"></span>
                Hadamard
              </span>
              <span className="flex items-center">
                <span className="w-2 h-2 bg-chart-3 rounded-full inline-block mr-1"></span>
                Rotation
              </span>
              <span className="flex items-center">
                <span className="w-2 h-2 bg-destructive rounded-full inline-block mr-1"></span>
                Measurement
              </span>
            </div>
          </div>
        </div>

        {/* Quantum State Probabilities */}
        {quantumState && (
          <div className="bg-muted/20 p-4 rounded-lg">
            <h4 className="text-sm font-semibold text-foreground mb-3">Quantum State Probabilities</h4>
            <div className="grid grid-cols-4 gap-2" data-testid="quantum-state-probabilities">
              {quantumState.amplitudes.slice(0, 4).map((amplitude, index) => (
                <div key={index} className="text-center">
                  <div className="text-xs text-muted-foreground mb-1">|{index.toString(2).padStart(2, '0')}⟩</div>
                  <div 
                    className="h-12 bg-primary/20 rounded-sm relative overflow-hidden"
                    data-testid={`probability-bar-${index}`}
                  >
                    <div 
                      className="absolute bottom-0 left-0 right-0 bg-primary transition-all duration-300"
                      style={{ height: `${amplitude.probability * 100}%` }}
                    />
                  </div>
                  <div className="text-xs text-foreground mt-1">
                    {(amplitude.probability * 100).toFixed(1)}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function cn(...classes: (string | undefined | boolean)[]): string {
  return classes.filter(Boolean).join(' ');
}
