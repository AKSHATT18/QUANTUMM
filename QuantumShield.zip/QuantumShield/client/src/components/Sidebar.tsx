import { Shield, BarChart3, Atom, Network, AlertTriangle, Lock, Settings, Gauge } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";

const navigation = [
  { name: "Dashboard", href: "/", icon: Gauge },
  { name: "Quantum Models", href: "/quantum", icon: Atom },
  { name: "Federated Network", href: "/federated", icon: Network },
  { name: "Fraud Detection", href: "/fraud", icon: AlertTriangle },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Privacy Controls", href: "/privacy", icon: Lock },
  { name: "Settings", href: "/settings", icon: Settings },
];

const systemStatus = [
  { name: "Quantum Engine", status: "Active", color: "accent", pulse: true },
  { name: "Fed Learning", status: "Training", color: "primary", pulse: true },
  { name: "Privacy Layer", status: "Secure", color: "accent", pulse: false },
];

export default function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="fixed inset-y-0 left-0 z-50 w-64 bg-card border-r border-border" data-testid="sidebar">
      <div className="flex items-center justify-center h-16 px-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
            <Shield className="w-4 h-4 text-primary-foreground" data-testid="logo-icon" />
          </div>
          <h1 className="text-xl font-bold gradient-text" data-testid="app-title">QuantumGuard</h1>
        </div>
      </div>
      
      <nav className="mt-6 px-3" data-testid="navigation">
        <div className="space-y-1">
          {navigation.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;
            
            return (
              <Link key={item.name} href={item.href}>
                <span 
                  className={cn(
                    "flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors cursor-pointer",
                    isActive
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  )}
                  data-testid={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <Icon className="mr-3 h-4 w-4" />
                  {item.name}
                </span>
              </Link>
            );
          })}
        </div>
        
        <div className="mt-8 pt-4 border-t border-border">
          <p className="px-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            System Status
          </p>
          <div className="mt-2 space-y-2" data-testid="system-status">
            {systemStatus.map((item) => (
              <div key={item.name} className="flex items-center justify-between px-3 py-1">
                <span className="text-xs text-muted-foreground">{item.name}</span>
                <div className="flex items-center">
                  <div 
                    className={cn(
                      "w-2 h-2 rounded-full mr-1",
                      item.color === "accent" ? "bg-accent" : "bg-primary",
                      item.pulse && "federated-pulse"
                    )}
                    data-testid={`status-indicator-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                  />
                  <span 
                    className={cn(
                      "text-xs",
                      item.color === "accent" ? "text-accent" : "text-primary"
                    )}
                    data-testid={`status-text-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {item.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </nav>
    </aside>
  );
}
