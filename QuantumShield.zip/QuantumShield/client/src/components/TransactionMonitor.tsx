import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Play, Pause, RefreshCw } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/useWebSocket";
import { formatDistanceToNow } from "date-fns";

interface Transaction {
  id: string;
  amount: number;
  fromAccount: string;
  toAccount: string;
  institutionId: string;
  timestamp: string;
  riskScore?: number;
  isApproved: boolean;
  isFraud: boolean;
}

interface TransactionWithStatus extends Transaction {
  status: 'approved' | 'flagged' | 'processing';
  displayRiskScore: number;
}

export default function TransactionMonitor() {
  const [isAutoRefresh, setIsAutoRefresh] = useState(true);
  const [realtimeTransactions, setRealtimeTransactions] = useState<TransactionWithStatus[]>([]);
  const { subscribe } = useWebSocket();

  const { data: transactions = [], isLoading, refetch } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    enabled: isAutoRefresh,
    refetchInterval: isAutoRefresh ? 3000 : false,
  });

  // Handle real-time transaction updates
  const handleTransactionUpdate = useCallback((data: any) => {
    const newTransaction: TransactionWithStatus = {
      ...data.transaction,
      status: data.status,
      displayRiskScore: data.riskScore,
    };

    setRealtimeTransactions(prev => {
      // Check if transaction already exists to avoid duplicates
      const existingIndex = prev.findIndex(tx => tx.id === newTransaction.id);
      if (existingIndex >= 0) {
        // Update existing transaction
        const updated = [...prev];
        updated[existingIndex] = newTransaction;
        return updated;
      }
      // Add new transaction at the beginning
      const updated = [newTransaction, ...prev.slice(0, 49)]; // Keep last 50 transactions
      return updated;
    });
  }, []);

  useEffect(() => {
    const unsubscribe = subscribe("transaction_update", handleTransactionUpdate);
    return unsubscribe;
  }, [subscribe, handleTransactionUpdate]);

  // Initialize with API data
  useEffect(() => {
    if (transactions.length > 0) {
      const processedTransactions: TransactionWithStatus[] = transactions.map((tx) => ({
        ...tx,
        status: tx.riskScore && tx.riskScore > 0.5 ? 'flagged' : 'approved',
        displayRiskScore: tx.riskScore || 0,
      }));
      setRealtimeTransactions(prev => {
        // Create a map for efficient lookup and merging
        const transactionMap = new Map();
        
        // Add existing realtime transactions (they have priority)
        prev.forEach(tx => transactionMap.set(tx.id, tx));
        
        // Add API transactions only if they don't exist
        processedTransactions.forEach(tx => {
          if (!transactionMap.has(tx.id)) {
            transactionMap.set(tx.id, tx);
          }
        });
        
        // Convert back to array and sort by timestamp (newest first)
        const mergedTransactions = Array.from(transactionMap.values())
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 50);
        
        return mergedTransactions;
      });
    }
  }, [transactions]);

  const toggleAutoRefresh = () => {
    setIsAutoRefresh(!isAutoRefresh);
  };

  const handleManualRefresh = () => {
    refetch();
  };

  const getStatusBadge = (status: string, riskScore: number) => {
    switch (status) {
      case 'flagged':
        return (
          <Badge variant="secondary" className="bg-destructive/10 text-destructive text-xs">
            <Pause className="h-3 w-3 mr-1" />
            Flagged
          </Badge>
        );
      case 'processing':
        return (
          <Badge variant="secondary" className="bg-primary/10 text-primary text-xs">
            <RefreshCw className="h-3 w-3 mr-1 animate-spin" />
            Processing
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary" className="bg-accent/10 text-accent text-xs">
            <Play className="h-3 w-3 mr-1" />
            Approved
          </Badge>
        );
    }
  };

  const getRiskScoreBadge = (riskScore: number) => {
    if (riskScore >= 0.8) {
      return <Badge variant="destructive" className="text-xs">High Risk</Badge>;
    } else if (riskScore >= 0.5) {
      return <Badge variant="secondary" className="bg-chart-3/10 text-chart-3 text-xs">Medium Risk</Badge>;
    } else if (riskScore >= 0.2) {
      return <Badge variant="secondary" className="bg-primary/10 text-primary text-xs">Low Risk</Badge>;
    } else {
      return <Badge variant="secondary" className="bg-accent/10 text-accent text-xs">Normal</Badge>;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const getInstitutionName = (institutionId: string) => {
    const names = {
      'bank-alpha': 'Bank Alpha',
      'credit-union-beta': 'Credit Union Beta',
      'fintech-gamma': 'FinTech Gamma',
    };
    return names[institutionId as keyof typeof names] || `Institution ${institutionId.slice(-4)}`;
  };

  if (isLoading && realtimeTransactions.length === 0) {
    return (
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle>Live Transaction Stream</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin h-6 w-6 border-2 border-primary border-t-transparent rounded-full"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-card border-border" data-testid="transaction-monitor">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Live Transaction Stream</span>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-muted-foreground">Auto-refresh:</span>
            <Button
              size="sm"
              variant={isAutoRefresh ? "default" : "outline"}
              onClick={toggleAutoRefresh}
              className="text-sm font-medium"
              data-testid="button-toggle-refresh"
            >
              {isAutoRefresh ? (
                <>
                  <Play className="h-3 w-3 mr-1" />
                  Active
                </>
              ) : (
                <>
                  <Pause className="h-3 w-3 mr-1" />
                  Paused
                </>
              )}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleManualRefresh}
              className="text-sm"
              data-testid="button-manual-refresh"
            >
              <RefreshCw className="h-3 w-3" />
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        {realtimeTransactions.length === 0 ? (
          <div className="text-center py-8" data-testid="no-transactions">
            <p className="text-muted-foreground">No transactions to display</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="transactions-table">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Timestamp</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Transaction ID</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Institution</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Risk Score</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Status</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {realtimeTransactions.slice(0, 20).map((transaction, index) => (
                  <tr 
                    key={transaction.id} 
                    className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${
                      index < 3 ? 'bg-primary/5' : '' // Highlight recent transactions
                    }`}
                    data-testid={`transaction-row-${transaction.id}`}
                  >
                    <td className="py-3 px-4 font-mono text-xs text-muted-foreground" data-testid={`transaction-timestamp-${transaction.id}`}>
                      {formatDistanceToNow(new Date(transaction.timestamp), { addSuffix: true })}
                    </td>
                    <td className="py-3 px-4 font-mono text-xs" data-testid={`transaction-id-${transaction.id}`}>
                      {transaction.id.slice(0, 8)}...
                    </td>
                    <td className="py-3 px-4 font-semibold text-foreground" data-testid={`transaction-amount-${transaction.id}`}>
                      {formatCurrency(transaction.amount)}
                    </td>
                    <td className="py-3 px-4 text-foreground" data-testid={`transaction-institution-${transaction.id}`}>
                      {getInstitutionName(transaction.institutionId)}
                    </td>
                    <td className="py-3 px-4" data-testid={`transaction-risk-${transaction.id}`}>
                      {getRiskScoreBadge(transaction.displayRiskScore)}
                    </td>
                    <td className="py-3 px-4" data-testid={`transaction-status-${transaction.id}`}>
                      {getStatusBadge(transaction.status, transaction.displayRiskScore)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
